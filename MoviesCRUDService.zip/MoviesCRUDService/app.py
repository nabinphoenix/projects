import os
from dotenv import load_dotenv
from typing import Optional, List, Dict
from enum import Enum
from datetime import datetime

from fastapi import FastAPI, HTTPException, status
from fastapi.responses import Response
from pydantic import BaseModel, Field
from pydantic.functional_validators import BeforeValidator
from typing_extensions import Annotated

from bson import ObjectId
import motor.motor_asyncio

# Load environment variables
load_dotenv()

# MongoDB connection setup
MONGODB_URL = os.environ.get("MONGODB_URL")
client = motor.motor_asyncio.AsyncIOMotorClient(MONGODB_URL)
db = client['sample_mflix']
movies_collection = db.get_collection("movies")

# Custom ObjectId handling
PyObjectId = Annotated[str, BeforeValidator(str)]

# IMDb submodel
class IMDb(BaseModel):
    rating: Optional[float] = None
    votes: Optional[int] = None
    id: Optional[int] = None

# Awards submodel
class Awards(BaseModel):
    wins: Optional[int] = None
    nominations: Optional[int] = None
    text: Optional[str] = None

# Main movie model
class MovieModel(BaseModel):
    id: Optional[PyObjectId] = Field(alias="_id", default=None)
    title: str
    year: int
    rated: Optional[str] = None
    released: Optional[datetime] = None  
    runtime: Optional[int] = None
    directors: Optional[List[str]] = None
    cast: Optional[List[str]] = None
    genres: Optional[List[str]] = None
    plot: Optional[str] = None
    fullplot: Optional[str] = None
    languages: Optional[List[str]] = None
    countries: Optional[List[str]] = None
    awards: Optional[Awards] = None
    imdb: Optional[IMDb] = None
    poster: Optional[str] = None
    type: Optional[str] = "movie"

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
        "json_encoders": {
            ObjectId: str,
            datetime: lambda v: v.isoformat() if v else None
        },
        "json_schema_extra": {
            "example": {
                "title": "The Great Train Robbery",
                "year": 1903,
                "rated": "TV-G",
                "released": "1903-12-01T00:00:00.000+00:00",
                "runtime": 11,
                "directors": ["Edwin S. Porter"],
                "cast": ["A.C. Abadie", "Justus D. Barnes"],
                "genres": ["Short", "Western"],
                "plot": "A group of bandits stage a brazen train hold-up...",
                "fullplot": "Among the earliest existing films in American cinema...",
                "languages": ["English"],
                "countries": ["USA"],
                "awards": {
                    "wins": 1,
                    "nominations": 0,
                    "text": "1 win."
                },
                "imdb": {
                    "rating": 7.4,
                    "votes": 9847,
                    "id": 439
                },
                "poster": "https://m.media-amazon.com/images/M/....jpg",
                "type": "movie"
            }
        }
    }

# FastAPI app initialization
app = FastAPI(
    title="Movies CRUD API",
    summary="Full CRUD operations on sample_mflix.movies",
)

# Helper: Serialize MongoDB documents
def serialize_movie(movie: dict) -> dict:
    movie["_id"] = str(movie["_id"])
    if "released" in movie and isinstance(movie["released"], datetime):
        movie["released"] = movie["released"].isoformat()
    return movie

# -----------------------
# CRUD ROUTES
# -----------------------

# CREATE
@app.post("/movies", response_model=MovieModel, status_code=status.HTTP_201_CREATED)
async def create_movie(movie: MovieModel):
    movie_dict = movie.model_dump(by_alias=True, exclude_unset=True)
    result = await movies_collection.insert_one(movie_dict)
    movie_dict["_id"] = result.inserted_id
    return serialize_movie(movie_dict)

# READ ALL
@app.get("/movies", response_model=List[MovieModel])
async def get_all_movies():
    movies = await movies_collection.find().to_list(length=100)
    return [serialize_movie(m) for m in movies]

# READ ONE
@app.get("/movies/{movie_id}", response_model=MovieModel)
async def get_movie(movie_id: str):
    try:
        movie = await movies_collection.find_one({"_id": ObjectId(movie_id)})
        if movie is None:
            raise HTTPException(status_code=404, detail="Movie not found")
        return serialize_movie(movie)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ObjectId format")

# UPDATE
@app.put("/movies/{movie_id}", response_model=MovieModel)
async def update_movie(movie_id: str, movie: MovieModel):
    movie_dict = movie.model_dump(by_alias=True, exclude_unset=True)
    try:
        updated = await movies_collection.find_one_and_update(
            {"_id": ObjectId(movie_id)},
            {"$set": movie_dict},
            return_document=True
        )
        if updated is None:
            raise HTTPException(status_code=404, detail="Movie not found")
        return serialize_movie(updated)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ObjectId format")

# DELETE
@app.delete("/movies/{movie_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_movie(movie_id: str):
    try:
        result = await movies_collection.delete_one({"_id": ObjectId(movie_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Movie not found")
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid ObjectId format")

# -----------------------
# AGGREGATION ROUTES
# -----------------------

# Top 5 by IMDb rating
@app.get("/aggregation/top-movies", response_model=List[Dict])
async def get_top_movies():
    pipeline = [
        {"$match": {"imdb.rating": {"$exists": True}}},
        {"$sort": {"imdb.rating": -1}},
        {"$limit": 5},
        {"$project": {
            "_id": 0,
            "title": 1,
            "year": 1,
            "rating": "$imdb.rating",
            "genres": 1
        }}
    ]
    results = await movies_collection.aggregate(pipeline).to_list(length=5)
    return results

# Top 5 with rating > 8.5
@app.get("/aggregation/top-movies-high-rating", response_model=List[Dict])
async def get_top_movies_high_rating():
    pipeline = [
        {"$match": {"imdb.rating": {"$gt": 8.5}}},
        {"$sort": {"imdb.rating": -1}},
        {"$limit": 5},
        {"$project": {
            "_id": 0,
            "title": 1,
            "year": 1,
            "rating": "$imdb.rating",
            "genres": 1
        }}
    ]
    results = await movies_collection.aggregate(pipeline).to_list(length=5)
    return results

# Average rating by genre
@app.get("/aggregation/average-rating-by-genre", response_model=List[Dict])
async def get_average_rating_by_genre():
    pipeline = [
        {"$match": {"imdb.rating": {"$exists": True}}},
        {"$unwind": "$genres"},
        {"$group": {
            "_id": "$genres",
            "average_rating": {"$avg": "$imdb.rating"},
            "count": {"$sum": 1}
        }},
        {"$sort": {"average_rating": -1}},
        {"$project": {
            "_id": 0,
            "genre": "$_id",
            "average_rating": 1,
            "count": 1
        }}
    ]
    results = await movies_collection.aggregate(pipeline).to_list(length=100)
    return results

# Movies count per year
@app.get("/aggregation/movies-count-yearly", response_model=List[Dict])
async def get_movies_count_yearly():
    pipeline = [
        {"$group": {
            "_id": "$year",
            "count": {"$sum": 1}
        }},
        {"$sort": {"_id": -1}},
        {"$project": {
            "_id": 0,
            "year": "$_id",
            "count": 1
        }}
    ]
    results = await movies_collection.aggregate(pipeline).to_list(length=100)
    return results

# Actors count (top 10)
@app.get("/aggregation/actors-count", response_model=List[Dict])
async def actors_count():
    pipeline = [
        {"$unwind": "$cast"},
        {"$group": {
            "_id": "$cast",
            "count": {"$sum": 1}
        }},
        {"$sort": {"count": -1}},
        {"$limit": 10},
        {"$project": {
            "_id": 0,
            "actor": "$_id",
            "count": 1
        }}
    ]    
    results = await movies_collection.aggregate(pipeline).to_list(length=10)
    return results
