package MainServices;

import Roles_and_Models.DeliveryRunner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DeliveryRunnerManager {
    // Path to the users.txt file
    private static final String USERS_FILE = "src/DataStore_and_Images/users.txt";

    // Returns the first available Delivery Runner from the users file
    public static DeliveryRunner getAvailableDeliveryRunner() {
        try (BufferedReader br = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Expected format: UserID,Name,Email,Password,Role
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String email = parts[2].trim();
                    String password = parts[3].trim(); // Added password
                    String role = parts[4].trim();

                    // Check if the ID starts with "D0" and the role is "Delivery Runner"
                    if (id.startsWith("D0") && role.equalsIgnoreCase("Delivery Runner")) {
                        // Create and return a new DeliveryRunner object with all required fields
                        return new DeliveryRunner(id, name, email, password);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading delivery runner data: " + e.getMessage());
        }
        return null; // if no available runner is found
    }
}
