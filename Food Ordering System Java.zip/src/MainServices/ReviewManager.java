package MainServices;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ReviewManager {
    // Relative path to the reviews.txt file
    private static final String REVIEWS_FILE = "src/DataStore_and_Images/reviews.txt";

    // Save a review to the reviews.txt file
    public static void saveReview(String customerName, String reviewedEntityName, String reviewText, String entityType) {
        // Ensure the DataStore_and_Images directory exists
        File dataDir = new File("DataStore_and_Images");
        if (!dataDir.exists()) {
            dataDir.mkdir(); // Create the DataStore_and_Images directory if it doesn't exist
        }



        try (BufferedWriter writer = new BufferedWriter(new FileWriter(REVIEWS_FILE, true))) {
            writer.write(customerName + "|" + reviewedEntityName + "|" + reviewText + "|" + entityType);
            writer.newLine();
            System.out.println("Review saved successfully!");
        } catch (IOException e) {
            System.err.println("Error saving review: " + e.getMessage());
        }
    }

    // Read reviews from the reviews.txt file based on entity type (Vendor or DeliveryRunner)
    public static List<String> readReviews(String entityType) {
        List<String> reviews = new ArrayList<>();

        // Ensure the DataStore_and_Images directory exists
        File dataDir = new File("DataStore_and_Images");
        if (!dataDir.exists()) {
            dataDir.mkdir(); // Create the DataStore_and_Images directory if it doesn't exist
        }


        try (BufferedReader reader = new BufferedReader(new FileReader(REVIEWS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 4 && parts[3].equals(entityType)) {
                    reviews.add(parts[0] + " reviewed " + parts[1] + ": " + parts[2]);
                }
            }
            System.out.println("Reviews read successfully!");
        } catch (FileNotFoundException e) {
            System.err.println("Error: The reviews file was not found at " + REVIEWS_FILE);
        } catch (IOException e) {
            System.err.println("Error reading reviews: " + e.getMessage());
        }
        return reviews;
    }
}