package MainServices;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class to read reviews from a text file.
 *
 * There are two expected file formats:
 *
 * 1. CSV format for vendor reviews:
 *    Expected format per line (comma-separated):
 *       ORD2,009,vend001,2,ACCEPTED,DELIVERY,2.5,good
 *    Here, the review is filtered by vendor id (token at index 2).
 *
 * 2. Pipe-delimited format for role-based reviews:
 *    Expected format per line:
 *       Deepak Shrestha|Sandar Express|gfds|Vendor
 *       Deepak Shrestha|Unknown Runner|sdf|DeliveryRunner
 *    Here, the review is filtered by the role specified in the fourth token.
 */
public class ReviewReader {

    /**
     * Reads reviews from a CSV file and filters them by vendor id.
     *
     * @param filePath path to the CSV file.
     * @param vendorId vendor id to filter reviews.
     * @return a list of formatted review strings.
     */
    public static List<String> readReviews(String filePath, String vendorId) {
        List<String> reviews = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                // Check if we have at least 8 parts and if the vendor id matches (parts[2])
                if (parts.length >= 8 && parts[2].trim().equals(vendorId)) {
                    // Extract only order ID (parts[0]), order number (parts[1]), and review (parts[7])
                    String orderId     = parts[0].trim();
                    String orderNumber = parts[1].trim();
                    String review      = parts[7].trim();

                    // Format the output string with required fields only
                    String formattedReview = "Order Num: " + orderNumber +
                            ", Order ID: " + orderId +
                            ", Review: " + review;
                    reviews.add(formattedReview);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return reviews;
    }

    /**
     * Reads reviews from a pipe-delimited file and filters them by role.
     * Expected format per line:
     *    Name|Company|SomeId|Role
     * For example:
     *    Deepak Shrestha|Sandar Express|gfds|Vendor
     *    Deepak Shrestha|Unknown Runner|sdf|DeliveryRunner
     *
     * @param filePath path to the pipe-delimited reviews file.
     * @param role role to filter reviews (e.g., "Vendor" or "DeliveryRunner").
     * @return a list of review strings that match the given role.
     */
    public static List<String> readReviewsForRole(String filePath, String role) {
        List<String> reviews = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line by "|" delimiter
                String[] parts = line.split("\\|");
                // Check if there are at least 4 parts and if the fourth token matches the role
                if (parts.length >= 4 && parts[3].trim().equalsIgnoreCase(role)) {
                    reviews.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return reviews;
    }
}
