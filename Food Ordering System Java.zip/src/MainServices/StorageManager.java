package MainServices;

import Roles_and_Models.*;
import java.io.*;
import java.util.*;

public class StorageManager {
    // Files in src/DataStore_and_Images/
    private static final String USERS_FILE = "src/DataStore_and_Images/users.txt";
    private static final String MENUS_FILE = "src/DataStore_and_Images/menus.txt";
    private static final String ORDERS_FILE = "src/DataStore_and_Images/orders.txt";
    private static final String NOTIFICATIONS_FILE = "src/DataStore_and_Images/notifications.txt";

    // Save users to USERS_FILE
    public static void saveUsers(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users) {
                writer.write(user.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }

    // Load users from USERS_FILE and return as a list
    public static List<User> loadUsers() {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(USERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                User user = User.fromCSV(line);
                if (user != null)
                    users.add(user);
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
        return users;
    }

    // Save menus: Each line is: vendorId,foodItemCSV
    public static void saveMenus(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(MENUS_FILE))) {
            for (User user : users) {
                if (user instanceof Vendor) {
                    Vendor vendor = (Vendor) user;
                    for (FoodItem item : vendor.getMenu()) {
                        writer.write(vendor.getId() + "," + item.toCSV());
                        writer.newLine();
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error saving menus: " + e.getMessage());
        }
    }

    // Load menus: assign FoodItems to the correct Vendor based on vendorId.
    public static void loadMenus(List<User> users) {
        Map<String, Vendor> vendorMap = new HashMap<>();
        for (User u : users) {
            if (u instanceof Vendor) {
                vendorMap.put(u.getId(), (Vendor) u);
            }
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(MENUS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Format: vendorId,itemId,name,price
                String[] parts = line.split(",", 2);
                if (parts.length < 2) continue;
                String vendorId = parts[0].trim();
                String foodCSV = parts[1].trim();
                FoodItem item = FoodItem.fromCSV(foodCSV);
                Vendor vendor = vendorMap.get(vendorId);
                if (vendor != null && item != null) {
                    vendor.addFoodItem(item);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading menus: " + e.getMessage());
        }
    }

    // Save orders to ORDERS_FILE
    public static void saveOrders(List<Order> orders) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ORDERS_FILE))) {
            for (Order order : orders) {
                writer.write(order.toCSV());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving orders: " + e.getMessage());
        }
    }

    // Load orders from ORDERS_FILE.
    // Since orders reference customers, vendors, and food items, we require maps.
    public static List<Order> loadOrders(Map<String, Customer> customerMap, Map<String, Vendor> vendorMap,
                                         Map<String, FoodItem> foodItemMap) {
        List<Order> orderList = new ArrayList<>();

        // Example: loading from a CSV file (you can replace it with your actual file loading logic)
        try (BufferedReader br = new BufferedReader(new FileReader(ORDERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                Order order = Order.fromCSV(line, customerMap, vendorMap, foodItemMap);
                if (order != null) {
                    orderList.add(order);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return orderList;
    }

    // Append a notification to the notifications file.
    public static void appendNotification(String notification) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(NOTIFICATIONS_FILE, true))) {
            writer.write(notification);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Error writing notification: " + e.getMessage());
        }
    }
}  