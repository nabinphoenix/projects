package MainServices;

import Roles_and_Models.Customer;

public class Payment {
    public static boolean processPayment(Customer cust, double amount) {
        if (cust.getCredit() >= amount) {
            cust.deductCredit(amount);
            return true;
        } else {
            return false;
        }
    }

    public static void refundPayment(Customer cust, double amount) {
        cust.topUpCredit(amount);
    }
}
