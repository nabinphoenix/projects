package MainServices;

import Roles_and_Models.User;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Notification {
    private static final String FILE_PATH = "src/DataStore_and_Images/notifications.txt";

    // Sends a notification by printing it to the console and logging it in a file.
    public static void sendNotification(User user, String message) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        // Replace actual newline characters with literal "\n" so the entire notification is on one line
        String escapedMessage = message.replace("\n", "\\n");
        // Build a JSON-like string without extra spaces
        String jsonNotification = String.format(
                "{\"user\":\"%s\",\"message\":\"%s\",\"timestamp\":\"%s\"}",
                escapeJson(user.getName()), escapeJson(escapedMessage), timestamp
        );
        // Print notification to console
        System.out.println("Notification for " + user.getName() + ": " + message);
        // Append the JSON-formatted notification to the file
        appendNotification(jsonNotification);
    }

    // Escapes quotes for JSON compatibility (basic implementation)
    private static String escapeJson(String str) {
        return str.replace("\"", "\\\"");
    }

    // Appends the notification string to the file
    private static void appendNotification(String notification) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            bw.write(notification);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Reads notifications for a given user from the file
    public static List<String> readNotifications(String userName) {
        List<String> notifications = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String userValue = extractJsonValue(line, "user");
                if (userValue != null && userValue.equalsIgnoreCase(userName)) {
                    String message = extractJsonValue(line, "message");
                    // Convert literal "\n" back to actual newline characters
                    if (message != null) {
                        message = message.replace("\\n", "\n");
                    }
                    String timestamp = extractJsonValue(line, "timestamp");
                    notifications.add(String.format("[%s] %s", timestamp, message));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return notifications;
    }

    // Extracts a value from a JSON-like string based on the given key
    private static String extractJsonValue(String json, String key) {
        String pattern = "\"" + key + "\":\"";
        int startIndex = json.indexOf(pattern);
        if (startIndex == -1) return null;
        startIndex += pattern.length();
        int endIndex = json.indexOf("\"", startIndex);
        if (endIndex == -1) return null;
        return json.substring(startIndex, endIndex);
    }
}
