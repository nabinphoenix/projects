package Roles_and_Models;

public class FoodItem {
    private String itemId;
    private String name;
    private double price;

    public FoodItem(String itemId, String name, double price) {
        this.itemId = itemId;
        this.name = name;
        this.price = price;
    }

    public String getItemId() { return itemId; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return itemId + " - " + name + ": $" + price;
    }

    // Convert to CSV (for menus.txt, note: vendorId is stored separately)
    public String toCSV() {
        return itemId + "," + name + "," + price;
    }

    public static FoodItem fromCSV(String csv) {
        String[] parts = csv.split(",");
        if(parts.length < 3) return null;
        return new FoodItem(parts[0].trim(), parts[1].trim(), Double.parseDouble(parts[2].trim()));
    }
}
