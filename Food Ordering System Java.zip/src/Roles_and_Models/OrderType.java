package Roles_and_Models;

public enum OrderType {
    DINE_IN, TAKEAWAY, DELIVERY
}
