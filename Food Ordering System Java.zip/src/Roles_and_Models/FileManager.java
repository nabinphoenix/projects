package Roles_and_Models;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileManager {

    /**
     * Load users (customers, vendors, delivery runners) from a file.
     */
    public static Map<String, User> loadUsers(String filePath) {
        Map<String, User> users = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String email = parts[2].trim();
                    String password = parts[3].trim();
                    String role = parts[4].trim();

                    switch (role) {
                        case "Customer":
                            double balance = (parts.length > 5) ? Double.parseDouble(parts[5].trim()) : 0.0;
                            users.put(id, new Customer(id, name, email, password, balance));
                            break;
                        case "Vendor":
                            users.put(id, new Vendor(id, name, email, password));
                            break;
                        case "Delivery Runner":
                            users.put(id, new DeliveryRunner(id, name, email, password));
                            break;
                        default:
                            System.err.println("Unknown role: " + role);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading users: " + e.getMessage());
        }
        return users;
    }

    /**
     * Load orders from a file.
     */
    public static List<Order> loadOrders(String filePath,
                                         Map<String, Customer> customerMap,
                                         Map<String, Vendor> vendorMap,
                                         Map<String, FoodItem> foodItemMap) {
        List<Order> orders = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (isHeader) {
                    isHeader = false; // Skip the header row
                    continue;
                }
                Order order = Order.fromCSV(line, customerMap, vendorMap, foodItemMap);
                if (order != null) {
                    orders.add(order);
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading orders: " + e.getMessage());
        }
        return orders;
    }

    /**
     * Load menus from a file.
     */
    public static List<FoodItem> loadMenus(String filePath) {
        List<FoodItem> menus = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (isHeader) {
                    isHeader = false; // Skip the header row
                    continue;
                }
                // Parse menu items (adjust based on file structure)
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String itemId = parts[0].trim();
                    String name = parts[1].trim();
                    double price = Double.parseDouble(parts[2].trim());
                    menus.add(new FoodItem(itemId, name, price));
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading menus: " + e.getMessage());
        }
        return menus;
    }

    /**
     * Load notifications from a file.
     */
    public static List<String> loadNotifications(String filePath) {
        List<String> notifications = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                notifications.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("Error loading notifications: " + e.getMessage());
        }
        return notifications;
    }

    /**
     * Load reviews from a file.
     */
    public static List<String> loadReviews(String filePath) {
        List<String> reviews = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                reviews.add(line.trim());
            }
        } catch (IOException e) {
            System.err.println("Error loading reviews: " + e.getMessage());
        }
        return reviews;
    }
}