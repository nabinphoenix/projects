package Roles_and_Models;

import java.util.Map;

public class DeliveryTask {
    private String taskId;
    private Order order;
    private DeliveryRunner runner;
    private String status;

    public DeliveryTask(String taskId, Order order, DeliveryRunner runner, String status) {
        this.taskId = taskId;
        this.order = order;
        this.runner = runner;
        this.status = status;


    }

    public String getTaskId() {
        return getOrderId();
    }

    public Order getOrder() {
        return order;
    }

    public DeliveryRunner getRunner() {
        return runner;
    }

    public void setRunner(DeliveryRunner runner) {
        this.runner = runner;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrderId() {
        return order.getOrderId();
    }

    @Override
    public String toString() {
        return "TaskID: " + taskId +
                " | OrderID: " + order.getOrderId() +
                " | Runner: " + (runner != null ? runner.getName() : "None") +
                " | Status: " + status;
    }


    // CSV format: taskId,orderId,runnerId (or empty),status
    public String toCSV() {
        String runnerId = (runner != null) ? runner.getId() : "";
        return taskId + "," + order.getOrderId() + "," + runnerId + "," + status;
    }

    public static DeliveryTask fromCSV(String csv,
                                       Map<String, Order> orderMap,
                                       Map<String, DeliveryRunner> runnerMap) {
        String[] parts = csv.split(",");
        if (parts.length < 4) {
            System.err.println("Invalid CSV format for DeliveryTask: " + csv);
            return null;
        }
        String taskId = parts[0].trim();
        String orderId = parts[1].trim();
        String runnerId = parts[2].trim();
        String status = parts[3].trim();
        Order order = orderMap.get(orderId);
        DeliveryRunner runner = (runnerId.isEmpty()) ? null : runnerMap.get(runnerId);
        return new DeliveryTask(taskId, order, runner, status);
    }
}
