package Roles_and_Models;

import java.util.ArrayList;
import java.util.List;

public class Vendor extends User {

    private List<FoodItem> menu;
    private List<Order> orders;

    public Vendor(String id, String name, String email, String password) {
        super(id, name, email, password);
        this.menu = new ArrayList<>();
        this.orders = new ArrayList<>();
    }

    @Override
    public String getRole() {
        return "Vendor";
    }

    public void addFoodItem(FoodItem item) {
        menu.add(item);
    }
    public List<FoodItem> getMenu() {
        return menu;
    }
    public void addOrder(Order order) {
        orders.add(order);
    }
    public List<Order> getOrders() {
        return orders;
    }

    public double calculateRevenue() {
        double revenue = 0;
        for (Order o : orders) {
            if (o.getStatus() == OrderStatus.ACCEPTED) {
                revenue += o.getTotalAmount();
            }
        }
        return revenue;
    }
}
