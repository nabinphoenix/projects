package Roles_and_Models;

public abstract class User {

    protected String id;
    protected String name;
    protected String email;
    protected String password;

    public User(String id, String name, String email, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public abstract String getRole();

    @Override
    public String toString() {
        return id + " - " + name + " (" + getRole() + ")";
    }

    // CSV format.
    // For Customers, include an extra field for credit.
    public String toCSV() {
        String base = id + "," + name + "," + email + "," + password + "," + getRole();
        if (this instanceof Customer) {
            return base + "," + ((Customer) this).getCredit();
        }
        return base;
    }

    // Create a User from a CSV line.
    public static User fromCSV(String csv) {
        String[] parts = csv.split(",");
        if (parts.length < 5) return null;
        String id = parts[0].trim();
        String name = parts[1].trim();
        String email = parts[2].trim();
        String password = parts[3].trim();
        String role = parts[4].trim();
        if (role.equals("Customer") && parts.length >= 6) {
            double credit = Double.parseDouble(parts[5].trim());
            return new Customer(id, name, email, password, credit);
        } else if (role.equals("Administrator")) {
            return new Administrator(id, name, email, password);
        } else if (role.equals("Vendor")) {
            return new Vendor(id, name, email, password);
        } else if (role.equals("Delivery Runner")) {
            return new DeliveryRunner(id, name, email, password);
        }
        return null;
    }

    // Setter for name.
    public void setName(String name) {
        this.name = name;
    }

    // Setter for email.
    public void setEmail(String newEmail) {
        this.email = newEmail;
    }

    // Setter for password.
    public void setPassword(String newPassword) {
        this.password = newPassword;
    }
}


