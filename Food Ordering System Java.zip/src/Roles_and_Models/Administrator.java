package Roles_and_Models;

import MainServices.Notification;
import MainGUIOfSystem.MainApplication;

import java.util.List;

public class Administrator extends User {

    public Administrator(String id, String name, String email, String password) {
        super(id, name, email, password);
    }

    @Override
    public String getRole() {
        return "Administrator";
    }

    /**
     * Tops up a customer's credit balance and sends a notification.
     *
     * @param cust   The customer whose credit is being topped up.
     * @param amount The amount to add to the customer's credit balance.
     */
    public void topUpCustomerCredit(Customer cust, double amount) {
        if (cust == null) {
            System.out.println("Error: Customer is null.");
            return;
        }
        cust.topUpCredit(amount);
        Notification.sendNotification(cust, "Your account has been credited with $" + amount);
    }

    /**
     * Generates a receipt for a given order.
     *
     * @param orderId The ID of the order to generate a receipt for.
     * @return A formatted receipt string, or an empty string if the order is not found.
     */
    public String generateReceipt(String orderId) {
        if (orderId == null || orderId.trim().isEmpty()) {
            return "Error: Order ID cannot be empty.";
        }

        Order order = MainApplication.getOrderById(orderId);
        if (order == null) {
            return "Error: Order with ID " + orderId + " not found.";
        }

        return "----- Receipt -----\n" +
                "Order ID: " + order.getOrderId() + "\n" +
                "Customer ID: " + order.getCustomerId() + "\n" +
                "Vendor ID: " + order.getVendorId() + "\n" +
                "Total Amount: $" + order.getTotalAmount() + "\n" +
                "Order Status: " + order.getStatus() + "\n" +
                "Delivery Option: " + order.getDeliveryOption() + "\n" +
                "-------------------";
    }

    /**
     * Sends a receipt for a given order to the customer.
     *
     * @param orderId The ID of the order to send a receipt for.
     */
    public void sendReceipt(String orderId) {
        if (orderId == null || orderId.trim().isEmpty()) {
            System.out.println("Error: Order ID cannot be empty.");
            return;
        }

        Order order = MainApplication.getOrderById(orderId);
        if (order == null) {
            System.out.println("Error: Order with ID " + orderId + " not found.");
            return;
        }

        String receipt = generateReceipt(orderId);
        if (receipt.startsWith("Error:")) {
            System.out.println(receipt); // Print the error message
            return;
        }

        // Locate the customer based on the customer ID from the order
        User customer = MainApplication.getUserById(order.getCustomerId());
        if (customer == null) {
            System.out.println("Error: Customer with ID " + order.getCustomerId() + " not found.");
            return;
        }

        // Send the receipt as a notification to the customer
        Notification.sendNotification(customer, "Receipt for Order #" + orderId + ":\n" + receipt);
        System.out.println("Receipt sent to customer " + customer.getName());
    }

    /**
     * Deletes a user with the specified ID.
     *
     * @param id The ID of the user to delete.
     */
    public void deleteUser(String id) {
        if (id == null || id.trim().isEmpty()) {
            System.out.println("Error: User ID cannot be empty.");
            return;
        }

        List<User> userList = MainApplication.getUserList();
        boolean removed = userList.removeIf(user -> user.getId().equals(id));
        if (removed) {
            System.out.println("User with ID " + id + " deleted successfully.");
        } else {
            System.out.println("Error: User with ID " + id + " not found.");
        }
    }

    /**
     * Updates an existing user by matching user ID.
     *
     * @param userToUpdate The updated user object.
     */
    public void updateUser(User userToUpdate) {
        if (userToUpdate == null) {
            System.out.println("Error: User to update cannot be null.");
            return;
        }

        List<User> userList = MainApplication.getUserList();
        for (int i = 0; i < userList.size(); i++) {
            if (userList.get(i).getId().equals(userToUpdate.getId())) {
                userList.set(i, userToUpdate);
                System.out.println("User with ID " + userToUpdate.getId() + " updated successfully.");
                return;
            }
        }
        System.out.println("Error: User with ID " + userToUpdate.getId() + " not found.");
    }

    /**
     * Creates a new user and adds it to the list.
     *
     * @param newUser The new user to add.
     */
    public void createUser(User newUser) {
        if (newUser == null) {
            System.out.println("Error: New user cannot be null.");
            return;
        }

        List<User> userList = MainApplication.getUserList();
        userList.add(newUser);
        System.out.println("User with ID " + newUser.getId() + " created successfully.");
    }

    /**
     * Returns all users as an array.
     *
     * @return An array of all users.
     */
    public User[] readUsers() {
        List<User> userList = MainApplication.getUserList();
        return userList.toArray(new User[0]);
    }
}