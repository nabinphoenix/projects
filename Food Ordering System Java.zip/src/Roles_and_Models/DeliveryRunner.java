package Roles_and_Models;

import java.util.ArrayList;
import java.util.List;

public class DeliveryRunner extends User {
    private List<DeliveryTask> taskHistory;
    private double earnings;

    public DeliveryRunner(String id, String name, String email, String password) {
        super(id, name, email, password);
        taskHistory = new ArrayList<>();
        earnings = 0;
    }

    @Override
    public String getRole() {
        return "Delivery Runner";
    }

    public void addTaskToHistory(DeliveryTask task) {
        taskHistory.add(task);
        // Increase earnings for each completed delivery (fixed fee)
        earnings += 5.00;
    }

    public List<DeliveryTask> getTaskHistory() {
        return taskHistory;
    }

    public double getEarnings() {
        return earnings;
    }

    /**
     * Check if the runner is available to take on a new task.
     * A runner is available if they have fewer than 5 tasks in their history.
     */
    public boolean isAvailable() {
        return taskHistory.size() < 5; // Example: Runner can handle up to 5 tasks
    }

    /**
     * Call this method when the runner has completed the delivery.
     * It updates the task status to "Completed", marks the associated order as DELIVERED,
     * adds the task to the runner's history, and outputs a confirmation message.
     */
    public void completeDeliveryTask(DeliveryTask task, String filePath) {
        if (task == null) {
            System.out.println("No task provided.");
            return;
        }
    }
}