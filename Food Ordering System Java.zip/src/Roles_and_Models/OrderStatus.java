package Roles_and_Models;

public enum OrderStatus {
    PENDING,    // Order is placed but not yet accepted by the vendor
    ACCEPTED,   // Vendor has accepted the order
    PREPARING,  // Vendor is preparing the order
    READY,      // Order is ready for pickup/delivery
    COMPLETED,  // Order has been delivered/completed
    CANCELLED,  // Order has been cancelled
    DECLINED,   // Vendor has declined the order
    DELIVERED;  // Order has been delivered by the delivery runner

    // Utility method to convert string to OrderStatus, returning PENDING for invalid statuses
    public static OrderStatus fromString(String status) {
        for (OrderStatus os : OrderStatus.values()) {
            if (os.name().equalsIgnoreCase(status)) {  // Case insensitive check
                return os;
            }
        }
        System.err.println("Invalid OrderStatus: " + status + ". Setting to default (PENDING).");
        return OrderStatus.PENDING;
    }
}
