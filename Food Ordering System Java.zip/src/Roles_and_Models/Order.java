package Roles_and_Models;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

public class Order {
    private String orderId;
    private Customer customer;
    private Vendor vendor;
    private List<FoodItem> items;
    private OrderStatus status;
    private OrderType orderType;
    private double deliveryFee;
    private String review;
    private DeliveryRunner deliveryRunner;

    public Order(String orderId, Customer customer, Vendor vendor, List<FoodItem> items, OrderStatus status, OrderType orderType) {
        this.orderId = orderId;
        this.customer = customer;
        this.vendor = vendor;
        this.items = items;
        this.status = status;
        this.orderType = orderType;
        this.deliveryFee = 0; // Default delivery fee
        this.review = "";     // Default review
    }

    public DeliveryRunner getDeliveryRunner() {
        return deliveryRunner;
    }

    public void setDeliveryRunner(DeliveryRunner deliveryRunner) {
        this.deliveryRunner = deliveryRunner;
    }

    public String getOrderId() {
        return orderId;
    }

    public double getDeliveryFee() {
        return deliveryFee;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public List<FoodItem> getItems() {
        return items;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public OrderType getOrderType() {
        return orderType;
    }

    public String getCustomerId() {
        return customer != null ? customer.getId() : "Unknown";
    }

    public String getVendorId() {
        return vendor != null ? vendor.getId() : "Unknown";
    }

    public String getOrderStatus() {
        return status != null ? status.name() : "Unknown";
    }

    public String getDeliveryOption() {
        return orderType != null ? orderType.name() : "Unknown";
    }

    public void setDeliveryFee(double fee) {
        this.deliveryFee = fee;
    }

    public double getTotalAmount() {
        double total = 0;
        for (FoodItem item : items) {
            total += item.getPrice();
        }
        return total + deliveryFee;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getReview() {
        return review;
    }

    @Override
    public String toString() {
        return "OrderID: " + orderId + " | Status: " + status + " | Total: $" + getTotalAmount();
    }

    // Updated CSV conversion method including order status and order type.
    // CSV Format: orderId,customerId,vendorId,itemId1;itemId2;...,deliveryFee,review,orderStatus,orderType
    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(orderId).append(",");
        sb.append(customer.getId()).append(",");
        sb.append(vendor.getId()).append(",");
        for (int i = 0; i < items.size(); i++) {
            sb.append(items.get(i).getItemId());
            if (i < items.size() - 1) {
                sb.append(";");
            }
        }
        sb.append(",").append(deliveryFee);
        sb.append(",").append(review.replace(",", " "));  // Replace commas to avoid CSV conflicts
        sb.append(",").append(status.name());
        sb.append(",").append(orderType.name());
        return sb.toString();
    }

    // Save the order status to a file
    public void saveOrderStatus(String filePath) {
        try (FileWriter writer = new FileWriter(filePath, true)) {
            writer.write(this.toCSV() + "\n");
        } catch (IOException e) {
            System.err.println("Error saving order status: " + e.getMessage());
        }
    }

    // Updated CSV parsing method to parse order status and order type.
    public static Order fromCSV(String csv,
                                Map<String, Customer> customerMap,
                                Map<String, Vendor> vendorMap,
                                Map<String, FoodItem> foodItemMap) {
        String[] parts = csv.split(",", -1);
        if (parts.length < 5) { // Minimum required fields: orderId,customerId,vendorId,items,deliveryFee
            System.err.println("Invalid CSV format: " + csv);
            return null;
        }

        String orderId = parts[0].trim();
        String custId = parts[1].trim();
        String vendId = parts[2].trim();
        String itemsStr = parts[3].trim();

        double deliveryFee = 0.0;
        try {
            deliveryFee = Double.parseDouble(parts[4].trim());
        } catch (NumberFormatException e) {
            System.err.println("Invalid delivery fee: " + parts[4] + ". Using default 0.");
        }

        // Default values for missing fields
        String review = (parts.length > 5) ? parts[5].trim() : "";
        OrderStatus status = (parts.length > 6) ? OrderStatus.fromString(parts[6].trim()) : OrderStatus.PENDING;
        OrderType orderType = (parts.length > 7) ? OrderType.valueOf(parts[7].trim()) : OrderType.DELIVERY;

        Customer cust = customerMap.get(custId);
        Vendor vend = vendorMap.get(vendId);
        List<FoodItem> items = new ArrayList<>();
        String[] itemIds = itemsStr.split(";");
        for (String id : itemIds) {
            FoodItem fi = foodItemMap.get(id.trim());
            if (fi != null) {
                items.add(fi);
            }
        }
        Order order = new Order(orderId, cust, vend, items, status, orderType);
        order.setDeliveryFee(deliveryFee);
        order.setReview(review);
        return order;
    }
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}