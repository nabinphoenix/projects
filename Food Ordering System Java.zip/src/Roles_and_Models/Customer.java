package Roles_and_Models;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {

    private double credit;
    private List<Order> orderHistory;
    private List<String> notifications;
    private List<String> transactionHistory;

    public Customer(String id, String name, String email, String password, double credit) {
        super(id, name, email, password);
        this.credit = credit;
        this.orderHistory = new ArrayList<>();
        this.notifications = new ArrayList<>();
        this.transactionHistory = new ArrayList<>();
    }

    @Override
    public String getRole() {
        return "Customer";
    }

    public double getCredit() {
        return credit;
    }

    public void topUpCredit(double amount) {
        credit += amount;
    }

    public void deductCredit(double amount) {
        credit -= amount;
    }

    public void addOrderHistory(Order order) {
        orderHistory.add(order);
    }

    public List<Order> getOrderHistory() {
        return orderHistory;
    }

    public double getCreditBalance() {
        return credit;
    }

    // Updated to return a List<String> for transaction history
    public List<String> getTransactionHistory() {
        return transactionHistory;
    }

    @Override
    public String toString() {
        return super.toString() + " | Credit: $" + credit;
    }

    // Update the customer's credit balance.
    public void setCreditBalance(double newCredit) {
        this.credit = newCredit;
    }

    // Add a notification to the customer's notification list
    public void addNotification(String notification) {
        notifications.add(notification);
    }

    // Add a transaction to the customer's transaction history
    public void addTransaction(String transaction) {
        transactionHistory.add(transaction);
    }

    // Return the list of notifications
    public List<String> getNotifications() {
        return notifications;
    }
}