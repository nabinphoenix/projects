package SystemValidation;

import java.io.*;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

public class UserProcessor {

    private static final String FILE_PATH = "src/DataStore_and_Images/users.txt";
    private static final String SECRET_KEY_FILE = "src/DataStore_and_Images/secret.key";

    public static void main(String[] args) {
        try {
            // Load or generate secret key
            SecretKey secretKey = loadOrGenerateKey();

            // Read, validate, and encrypt passwords
            List<String> updatedUsers = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] userData = line.split(",");
                    if (userData.length < 5) continue; // Skip invalid lines

                    String email = userData[2].trim();  // Email (3rd field)
                    String password = userData[3].trim(); // Password (4th field)

                    // Validate email
                    if (!EmailValidator.validateEmail(email)) {
                        System.out.println("Invalid email: " + email);
                        continue; // Skip invalid email entries
                    }

                    // Encrypt password
                    String encryptedPassword = PasswordEncryptor.encrypt(password, secretKey);
                    userData[3] = encryptedPassword; // Update password field

                    // Store updated user info
                    updatedUsers.add(String.join(",", userData));
                }
            }

            // Write back the updated DataStore_and_Images to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
                for (String updatedLine : updatedUsers) {
                    writer.write(updatedLine);
                    writer.newLine();
                }
            }

            System.out.println("User DataStore_and_Images processed successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load secret key from file or generate a new one
    private static SecretKey loadOrGenerateKey() throws Exception {
        File keyFile = new File(SECRET_KEY_FILE);
        if (keyFile.exists()) {
            try (FileInputStream fis = new FileInputStream(keyFile)) {
                byte[] keyBytes = fis.readAllBytes();
                return new SecretKeySpec(keyBytes, "AES");
            }
        } else {
            SecretKey secretKey = PasswordEncryptor.generateKey();
            try (FileOutputStream fos = new FileOutputStream(SECRET_KEY_FILE)) {
                fos.write(secretKey.getEncoded());
            }
            return secretKey;
        }
    }
}
