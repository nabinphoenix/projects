package SystemValidation;

import java.util.regex.Pattern;

public class NameValidator {

    // Regular expression to validate names
    private static final String NAME_REGEX = "^[A-Z][a-z]+\\s[A-Z][a-z]+$";

    // Compile the regex pattern
    private static final Pattern NAME_PATTERN = Pattern.compile(NAME_REGEX);

    // Validate name
    public static boolean validateName(String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        return NAME_PATTERN.matcher(name).matches();
    }
}
