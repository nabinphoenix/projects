package SystemValidation;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class DecryptExample {
    public static void main(String[] args) throws Exception {
        // Provided AES key (base64 decoded)
        String base64Key = "MbJsJBf+iQ6FZ7jXwq5EqQ==";
        byte[] keyBytes = Base64.getDecoder().decode(base64Key);
        // The encrypted password you want to decrypt
        String encryptedPassword = "v3WkI4ALfCct5KFeUfD6zQ==";
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedPassword);
        // Initialize AES cipher with the key
        SecretKeySpec secretKey = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        // Decrypt the password
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        String decryptedPassword = new String(decryptedBytes);
        // Output the decrypted password
        System.out.println("Decrypted Password: " + decryptedPassword);
    }
}


