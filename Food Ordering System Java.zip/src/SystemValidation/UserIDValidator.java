package SystemValidation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Pattern;

public class UserIDValidator {

    // Regular expressions to validate User IDs
    private static final String CUSTOMER_ID_REGEX = "^C0\\d{2}$";
    private static final String VENDOR_ID_REGEX = "^V0\\d{2}$";
    private static final String DELIVERY_RUNNER_ID_REGEX = "^D0\\d{2}$";

    // Compile the regex patterns
    private static final Pattern CUSTOMER_ID_PATTERN = Pattern.compile(CUSTOMER_ID_REGEX);
    private static final Pattern VENDOR_ID_PATTERN = Pattern.compile(VENDOR_ID_REGEX);
    private static final Pattern DELIVERY_RUNNER_ID_PATTERN = Pattern.compile(DELIVERY_RUNNER_ID_REGEX);

    private static final String USER_FILE_PATH = "src/DataStore_and_Images/users.txt"; // Path to users.txt file

    // Validate Customer ID
    public static boolean validateCustomerID(String customerID) {
        return customerID != null && !customerID.isEmpty() && CUSTOMER_ID_PATTERN.matcher(customerID).matches();
    }

    // Validate Vendor ID
    public static boolean validateVendorID(String vendorID) {
        return vendorID != null && !vendorID.isEmpty() && VENDOR_ID_PATTERN.matcher(vendorID).matches();
    }

    // Validate Delivery Runner ID
    public static boolean validateDeliveryRunnerID(String deliveryRunnerID) {
        return deliveryRunnerID != null && !deliveryRunnerID.isEmpty() && DELIVERY_RUNNER_ID_PATTERN.matcher(deliveryRunnerID)
                .matches();
    }

    // Check if the userID is unique in users.txt file
    public static boolean isUserIDUnique(String userID) {
        File file = new File(USER_FILE_PATH);

        if (!file.exists()) {
            return true; // If file doesn't exist, no duplicate userID
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(","); // Assuming CSV format: userID,name,email,password,role
                if (parts.length > 0 && parts[0].equals(userID)) {
                    return false; // userID already exists
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading users.txt: " + e.getMessage());
        }

        return true; // userID is unique
    }

    // Validate User ID dynamically
    public static boolean validateUserID(String id) {
        if (id == null || id.isEmpty()) {
            return false;
        }

        // Check if it matches any valid ID pattern and ensure it's unique
        return (validateCustomerID(id) || validateVendorID(id) || validateDeliveryRunnerID(id)) && isUserIDUnique(id);
    }
}
