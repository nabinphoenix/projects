package SystemValidation;

import java.util.regex.Pattern;

public class EmailValidator {

    // Regular expression to validate email:
    // - Must contain at least one digit.
    // - Allowed characters before the @ are letters, digits, plus, underscore, period, and hyphen.
    // - The domain part must contain at least one dot with at least two letters following it.
    private static final String EMAIL_REGEX =
            "^(?=.*\\d)[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

    // Compile the regex pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    // Validate email
    public static boolean validateEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email).matches();
    }
}
