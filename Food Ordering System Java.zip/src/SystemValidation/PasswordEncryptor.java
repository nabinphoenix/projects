package SystemValidation;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Properties;

public class PasswordEncryptor {

    private static final String ALGORITHM = "AES";
    private static final String KEY_FILE = "src/DataStore_and_Images/secretKey.properties"; // File to store the key

    // Generate a new AES key and save it to a properties file.
    public static SecretKey generateKey() throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
        keyGenerator.init(128); // 128-bit AES key
        SecretKey secretKey = keyGenerator.generateKey();
        saveKey(secretKey);
        return secretKey;
    }

    // Save the secret key to a properties file.
    private static void saveKey(SecretKey secretKey) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("AESKey", Base64.getEncoder().encodeToString(secretKey.getEncoded()));

        try (FileOutputStream fos = new FileOutputStream(KEY_FILE)) {
            properties.store(fos, "AES Encryption Key");
        }
    }

    // Load the secret key from the properties file.
    public static SecretKey loadKey() throws IOException {
        Properties properties = new Properties();
        try (FileInputStream fis = new FileInputStream(KEY_FILE)) {
            properties.load(fis);
        }
        byte[] decodedKey = Base64.getDecoder().decode(properties.getProperty("AESKey"));
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, ALGORITHM);
    }

    // Encrypt the given password using the provided secret key.
    public static String encrypt(String password, SecretKey secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
        byte[] encryptedBytes = cipher.doFinal(password.getBytes());
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    // Decrypt the given encrypted password using the provided secret key.
    public static String decrypt(String encryptedPassword, SecretKey secretKey) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedPassword));
        return new String(decryptedBytes);
    }

    // Load the secret key if it exists; otherwise, generate a new key.
    public static SecretKey loadOrGenerateKey() throws Exception {
        File keyFile = new File(KEY_FILE);
        if (keyFile.exists()) {
            return loadKey();
        } else {
            return generateKey();
        }
    }
}
