package SystemValidation;

import java.util.regex.Pattern;

public class PasswordValidator {

    // Regular expression to validate password:
    // - At least one digit, one lowercase letter, one uppercase letter, one special character.
    // - No whitespace allowed.
    // - Length between 8 and 16 characters.
    private static final String PASSWORD_REGEX =
            "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*])(?=\\S+$).{8,16}$";

    // Compile the regex pattern
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);

    // Validate password
    public static boolean validatePassword(String password) {
        if (password == null || password.isEmpty()) {
            return false;
        }
        return PASSWORD_PATTERN.matcher(password).matches();
    }
}

