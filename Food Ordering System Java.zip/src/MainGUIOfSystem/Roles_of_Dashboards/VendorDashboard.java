package MainGUIOfSystem.Roles_of_Dashboards;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import Roles_and_Models.FoodItem;
import Roles_and_Models.Vendor;
import MainGUIOfSystem.MainApplication;
import MainGUIOfSystem.ButtonActions.AddMenuItem;
import MainGUIOfSystem.ButtonActions.UpdateDeleteMenuItems;
import MainGUIOfSystem.ButtonActions.ProcessOrderDialog;

public class VendorDashboard extends JPanel {
    private MainApplication mainFrame;
    private Vendor vendor;

    // Updated main dashboard button dimensions and border radius
    private static final int BUTTON_WIDTH = 220;
    private static final int BUTTON_HEIGHT = 45;
    private static final int BUTTON_CORNER_RADIUS = 30;

    // Logout button dimensions are now equal to the main button dimensions
    private static final int LOGOUT_BUTTON_WIDTH = BUTTON_WIDTH;
    private static final int LOGOUT_BUTTON_HEIGHT = BUTTON_HEIGHT;

    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    // Dialog button styling constants (maintained)
    private static final int DIALOG_BUTTON_WIDTH = 100;
    private static final int DIALOG_BUTTON_HEIGHT = 50;
    private static final int DIALOG_BUTTON_CORNER_RADIUS = 25;

    public VendorDashboard(MainApplication frame, Vendor vendor) {
        this.mainFrame = frame;
        this.vendor = vendor;
        setLayout(new BorderLayout(10, 10));
        setBackground(BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Header Panel with scaled logo and welcome message
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Scale the logo image to an appropriate size
        ImageIcon logoIcon = new ImageIcon("src/DataStore_and_Images/logo.png");
        Image scaledLogoImage = logoIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogoImage));
        headerPanel.add(logoLabel, BorderLayout.WEST);

        // Add Vendor image
        ImageIcon vendorIcon = new ImageIcon("src/DataStore_and_Images/Vendor.png");
        Image scaledVendorImage = vendorIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel vendorLabel = new JLabel(new ImageIcon(scaledVendorImage));
        headerPanel.add(vendorLabel, BorderLayout.EAST);

        JLabel welcomeLabel = new JLabel("Welcome, Vendor: " + vendor.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(TEXT_COLOR);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        // Create a panel for the 6 main buttons arranged in a grid (3 rows, 2 columns)
        JPanel gridPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        gridPanel.setBackground(BACKGROUND_COLOR);
        gridPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create the 6 main dashboard buttons with updated dimensions and font size
        JButton viewMenuButton = createStyledButton("View Full Menu", BUTTON_WIDTH, BUTTON_HEIGHT);
        JButton addFoodButton = createStyledButton("Add Menu Item", BUTTON_WIDTH, BUTTON_HEIGHT);
        JButton manageFoodButton = createStyledButton("Update and Delete Menu Item", BUTTON_WIDTH, BUTTON_HEIGHT);
        JButton viewOrdersButton = createStyledButton("View and Process Orders", BUTTON_WIDTH, BUTTON_HEIGHT);
        JButton revenueButton = createStyledButton("Revenue Dashboard", BUTTON_WIDTH, BUTTON_HEIGHT);
        JButton seeReviewsButton = createStyledButton("Read Customer Reviews", BUTTON_WIDTH, BUTTON_HEIGHT);

        // Add the 6 buttons to the grid panel (2 per row)
        gridPanel.add(viewMenuButton);
        gridPanel.add(addFoodButton);
        gridPanel.add(manageFoodButton);
        gridPanel.add(viewOrdersButton);
        gridPanel.add(revenueButton);
        gridPanel.add(seeReviewsButton);

        // Create a separate panel for the Logout button, with equal size
        JPanel logoutPanel = new JPanel();
        logoutPanel.setBackground(BACKGROUND_COLOR);
        JButton logoutButton = createStyledButton("Logout", LOGOUT_BUTTON_WIDTH, LOGOUT_BUTTON_HEIGHT);
        logoutPanel.add(logoutButton);

        // Add the panels to the main container
        add(gridPanel, BorderLayout.CENTER);
        add(logoutPanel, BorderLayout.SOUTH);

        // Initialize button actions for all buttons
        initializeButtonActions(viewMenuButton, addFoodButton, manageFoodButton,
                viewOrdersButton, revenueButton, seeReviewsButton, logoutButton);
    }

    /**
     * Initializes actions for all dashboard buttons.
     */
    private void initializeButtonActions(JButton viewMenuButton, JButton addFoodButton, JButton manageFoodButton,
                                         JButton viewOrdersButton, JButton revenueButton,
                                         JButton seeReviewsButton, JButton logoutButton) {
        // Action for "View Full Menu"
        viewMenuButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            // Iterate over users to find vendors and list their menu items
            for (Roles_and_Models.User u : MainApplication.userList) {
                if (u instanceof Vendor) {
                    Vendor vend = (Vendor) u;
                    sb.append("Vendor: ").append(vend.getName()).append("\n");
                    for (FoodItem item : vend.getMenu()) {
                        sb.append("  ").append(item.toString()).append("\n");
                    }
                    sb.append("\n");
                }
            }
            showCustomMessageDialog("Menu", sb.toString(), 500, 300);
        });

        // Action for "Add Menu Item"
        addFoodButton.addActionListener(e -> new AddMenuItem(mainFrame, vendor).setVisible(true));

        // Action for "Update and Delete Menu Item"
        manageFoodButton.addActionListener(e -> new UpdateDeleteMenuItems(mainFrame, vendor).setVisible(true));

        // Action for "View/Process Orders"
        viewOrdersButton.addActionListener(e -> new ProcessOrderDialog(mainFrame, vendor).setVisible(true));

        // Action for "Revenue Dashboard"
        revenueButton.addActionListener(e -> {
            double revenue = vendor.calculateRevenue();
            showCustomMessageDialog("Revenue Dashboard", "Total Revenue: $" + revenue, 500, 300);
        });

        // Action for "Read Customer Reviews"
        seeReviewsButton.addActionListener(e -> {
            // Get reviews filtered by role "Vendor"
            List<String> reviews = MainServices.ReviewReader.readReviewsForRole("src/DataStore_and_Images/reviews.txt", "Vendor");
            if (reviews.isEmpty()) {
                showCustomMessageDialog("Reviews", "No reviews found for your vendor.", 500, 300);
            } else {
                StringBuilder sb = new StringBuilder();
                // Process each review line
                for (String reviewLine : reviews) {
                    // Assuming the review file format is: CustomerName|SomeField|ReviewText|Role
                    String[] tokens = reviewLine.split("\\|");
                    if (tokens.length >= 3) {
                        String customerName = tokens[0].trim();
                        String reviewText = tokens[2].trim();
                        sb.append("Customer: ").append(customerName)
                                .append("\nReview: ").append(reviewText)
                                .append("\n\n");
                    }
                }
                showCustomMessageDialog("Reviews", sb.toString(), 500, 300);
            }
        });

        // Action for "Logout"
        logoutButton.addActionListener(e -> {
            MainApplication.currentUser = null;
            mainFrame.getMainPanel().removeAll();
            mainFrame.getMainPanel().add(new MainLoginDashboard(mainFrame), "Login");
            mainFrame.getCardLayout().show(mainFrame.getMainPanel(), "Login");
        });
    }

    /**
     * Helper method to create a styled button for the main dashboard.
     */
    private JButton createStyledButton(String text, int width, int height) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), BUTTON_CORNER_RADIUS, BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(width, height));
        // Updated font size to 16 for all buttons
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(BUTTON_CORNER_RADIUS));
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(new Color(0xA0, 0x00, 0xA0));
                button.setForeground(Color.WHITE);
            }
            @Override
            public void mouseExited(MouseEvent evt) {
                button.setBackground(BUTTON_COLOR);
                button.setForeground(TEXT_COLOR);
            }
        });
        return button;
    }

    /**
     * Custom dialog to display messages with a consistent GUI style.
     */
    private void showCustomMessageDialog(String title, String message, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setForeground(TEXT_COLOR);
        textArea.setBackground(BACKGROUND_COLOR);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(width - 50, height - 100));
        dialog.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton closeButton = createDialogStyledButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setSize(width, height);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
    }

    /**
     * Helper method to create a styled button for ButtonActions.
     */
    private JButton createDialogStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), DIALOG_BUTTON_CORNER_RADIUS, DIALOG_BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(DIALOG_BUTTON_WIDTH, DIALOG_BUTTON_HEIGHT));
        // Updated font size to 16 for dialog buttons as well
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(DIALOG_BUTTON_CORNER_RADIUS));
        // Hover effect for dialog buttons
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }
}

