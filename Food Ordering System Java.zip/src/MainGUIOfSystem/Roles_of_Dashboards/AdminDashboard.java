package MainGUIOfSystem.Roles_of_Dashboards;

import MainGUIOfSystem.MainApplication;
import Roles_and_Models.*;
import MainServices.StorageManager;
import SystemValidation.EmailValidator;
import SystemValidation.PasswordEncryptor;
import SystemValidation.UserIDValidator;
import SystemValidation.NameValidator;
import SystemValidation.PasswordValidator;

import javax.crypto.SecretKey;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AdminDashboard extends JPanel {
    private MainApplication mainFrame;
    private Administrator admin;

    // Colors used in the GUI
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    // Main button styling constants
    private static final int BUTTON_SIZE = 100;
    private static final int BUTTON_CORNER_RADIUS = 30;

    // Dialog button styling constants (smaller size)
    private static final int DIALOG_BUTTON_WIDTH = 80;
    private static final int DIALOG_BUTTON_HEIGHT = 40;
    private static final int DIALOG_BUTTON_CORNER_RADIUS = 20;

    public AdminDashboard(MainApplication frame, Administrator admin) {
        this.mainFrame = frame;
        this.admin = admin;

        // Set up panel
        setLayout(new BorderLayout(10, 10));
        setBackground(BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // ========== HEADER PANEL ==========
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Left: Logo
        ImageIcon logoIcon = new ImageIcon("src/DataStore_and_Images/logo.png");
        Image scaledLogoImage = logoIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogoImage));

        // Center: Welcome label
        JLabel welcomeLabel = new JLabel("Welcome, Administrator " + admin.getName(), JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(TEXT_COLOR);

        // Right: Admin icon
        ImageIcon adminIcon = new ImageIcon("src/DataStore_and_Images/admin_logo.png");
        Image scaledAdminImage = adminIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel adminIconLabel = new JLabel(new ImageIcon(scaledAdminImage));

        headerPanel.add(logoLabel, BorderLayout.WEST);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        headerPanel.add(adminIconLabel, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // ========== BUTTON PANEL ==========
        // Arrange 6 buttons in a 2×3 grid, plus logout at the bottom.
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(BACKGROUND_COLOR);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Create buttons using the custom styled method
        JButton createUserButton      = createStyledButton("Create User");
        JButton updateUserButton      = createStyledButton("Update User");
        JButton deleteUserButton      = createStyledButton("Delete User");
        JButton topUpCreditButton     = createStyledButton("Top-Up Credit");
        JButton generateReceiptButton = createStyledButton("Generate Receipt");
        JButton sendReceiptButton     = createStyledButton("Send Receipt");
        JButton logoutButton          = createStyledButton("Logout");

        // Place the 6 main buttons in a 2×3 grid
        gbc.gridy = 0;
        gbc.gridx = 0;
        buttonPanel.add(createUserButton, gbc);

        gbc.gridx = 1;
        buttonPanel.add(updateUserButton, gbc);

        gbc.gridx = 2;
        buttonPanel.add(deleteUserButton, gbc);

        gbc.gridy = 1;
        gbc.gridx = 0;
        buttonPanel.add(topUpCreditButton, gbc);

        gbc.gridx = 1;
        buttonPanel.add(generateReceiptButton, gbc);

        gbc.gridx = 2;
        buttonPanel.add(sendReceiptButton, gbc);

        // Place the logout button on a separate row spanning all columns
        gbc.gridy = 2;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        buttonPanel.add(logoutButton, gbc);

        add(buttonPanel, BorderLayout.CENTER);

        // =====================
        // Create User Logic
        // =====================
        createUserButton.addActionListener(e -> {
            String[] userTypes = {"Customer", "Vendor", "DeliveryRunner"};
            String userType = showCustomSelectionDialog("Create User", "Select user type:", userTypes, 400, 150);
            if (userType != null && !userType.isEmpty()) {
                String id = showCustomInputDialog("Enter User ID", "Please enter User ID:", 400, 150);
                String name = showCustomInputDialog("Enter Name", "Please enter Name:", 400, 150);
                String email = showCustomInputDialog("Enter Email", "Please enter Email:", 400, 150);
                String password = showCustomInputDialog("Enter Password", "Please enter Password:", 400, 150);

                // Validate User ID, email, and password before proceeding
                if (!UserIDValidator.validateUserID(id)) {
                    showCustomMessageDialog("Error", "Invalid User ID format.", 400, 150);
                    return;
                }
                if (!EmailValidator.validateEmail(email)) {
                    showCustomMessageDialog("Error", "Invalid email format.", 400, 150);
                    return;
                }
                if (!PasswordValidator.validatePassword(password)) {
                    showCustomMessageDialog("Error",
                            "Invalid password. It must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character.",
                            500, 200);
                    return;
                }

                // Check if the User ID already exists
                for (User existingUser : MainApplication.userList) {
                    if (existingUser.getId().equals(id)) {
                        showCustomMessageDialog("Error", "User ID already exists.", 400, 150);
                        return;
                    }
                }

                if (id != null && name != null && email != null && password != null) {
                    User newUser = null;
                    if (userType.equals("Customer")) {
                        String creditStr = showCustomInputDialog("Enter Initial Credit", "Please enter Initial Credit:", 400, 150);
                        double credit = Double.parseDouble(creditStr);
                        newUser = new Customer(id, name, email, password, credit);
                    } else if (userType.equals("Vendor")) {
                        newUser = new Vendor(id, name, email, password);
                    } else if (userType.equals("DeliveryRunner")) {
                        newUser = new DeliveryRunner(id, name, email, password);
                    }

                    if (newUser != null) {
                        // Optionally, encrypt the password before storing
                        try {
                            SecretKey secretKey = PasswordEncryptor.loadOrGenerateKey();
                            String encryptedPassword = PasswordEncryptor.encrypt(password, secretKey);
                            newUser.setPassword(encryptedPassword);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }

                        admin.createUser(newUser);
                        StorageManager.saveUsers(MainApplication.userList);
                        showCustomMessageDialog("Success", "User created successfully.", 400, 150);
                    }
                }
            }
        });

        // =====================
        // Update User Logic
        // =====================
        updateUserButton.addActionListener(e -> {
            String id = showCustomInputDialog("Update User", "Enter User ID to update:", 400, 150);
            if (id != null && !id.trim().isEmpty()) {
                User userToUpdate = null;
                for (User user : MainApplication.userList) {
                    if (user.getId().equals(id)) {
                        userToUpdate = user;
                        break;
                    }
                }
                if (userToUpdate != null) {
                    String name = showCustomInputDialog("Update User", "Enter new Name:", userToUpdate.getName(), 400, 150);
                    String email = showCustomInputDialog("Update User", "Enter new Email:", userToUpdate.getEmail(), 400, 150);
                    String password = showCustomInputDialog("Update User", "Enter new Password:", 400, 150);

                    if (!NameValidator.validateName(name)) {
                        showCustomMessageDialog("Error", "Invalid Name format.", 400, 150);
                        return;
                    }
                    if (!EmailValidator.validateEmail(email)) {
                        showCustomMessageDialog("Error", "Invalid email format.", 400, 150);
                        return;
                    }
                    if (!PasswordValidator.validatePassword(password)) {
                        showCustomMessageDialog("Error",
                                "Invalid password. It must be 8-16 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character.",
                                500, 200);
                        return;
                    }

                    // Check if the new email is already in use by another user
                    for (User u : MainApplication.userList) {
                        if (u != userToUpdate && u.getEmail().equals(email)) {
                            showCustomMessageDialog("Error", "Email is already in use by another user.", 400, 150);
                            return;
                        }
                    }

                    // Load the encryption key
                    SecretKey secretKey = null;
                    try {
                        secretKey = PasswordEncryptor.loadKey();
                    } catch (Exception ex) {
                        showCustomMessageDialog("Error", "Error loading encryption key", 400, 150);
                        return;
                    }

                    // Encrypt the new password
                    String encryptedPassword = null;
                    try {
                        encryptedPassword = PasswordEncryptor.encrypt(password, secretKey);
                    } catch (Exception ex) {
                        showCustomMessageDialog("Error", "Error encrypting password", 400, 150);
                        return;
                    }

                    // If it's a Customer, allow updating credit balance
                    if (userToUpdate instanceof Customer) {
                        String creditStr = showCustomInputDialog("Update User", "Enter new Credit Balance:",
                                String.valueOf(((Customer) userToUpdate).getCreditBalance()), 400, 150);
                        if (creditStr != null) {
                            try {
                                double credit = Double.parseDouble(creditStr);
                                ((Customer) userToUpdate).setCreditBalance(credit);
                            } catch (NumberFormatException ex) {
                                showCustomMessageDialog("Error", "Invalid credit format.", 400, 150);
                                return;
                            }
                        }
                    }

                    userToUpdate.setName(name);
                    userToUpdate.setEmail(email);
                    userToUpdate.setPassword(encryptedPassword);

                    admin.updateUser(userToUpdate);
                    StorageManager.saveUsers(MainApplication.userList);
                    showCustomMessageDialog("Success", "User updated successfully.", 400, 150);
                } else {
                    showCustomMessageDialog("Error", "User not found.", 400, 150);
                }
            } else {
                showCustomMessageDialog("Error", "Please enter a valid User ID.", 400, 150);
            }
        });

        // =====================
        // Delete User Logic
        // =====================
        deleteUserButton.addActionListener(e -> {
            String id = showCustomInputDialog("Delete User", "Enter User ID to delete:", 400, 150);
            if (id != null && !id.trim().isEmpty()) {
                admin.deleteUser(id);
                StorageManager.saveUsers(MainApplication.userList);
                showCustomMessageDialog("Success", "User deletion processed.", 400, 150);
            }
        });

        // =====================
        // Top-Up Credit Logic
        // =====================
        topUpCreditButton.addActionListener(e -> {
            String customerId = showCustomInputDialog("Top-Up Credit", "Enter Customer ID:", 400, 150);
            String amountStr = showCustomInputDialog("Top-Up Credit", "Enter Amount:", 400, 150);
            if (customerId != null && amountStr != null &&
                    !customerId.trim().isEmpty() && !amountStr.trim().isEmpty()) {
                try {
                    double amount = Double.parseDouble(amountStr);
                    Customer cust = null;
                    for (User u : MainApplication.userList) {
                        if (u instanceof Customer && u.getId().equals(customerId)) {
                            cust = (Customer) u;
                            break;
                        }
                    }
                    if (cust != null) {
                        admin.topUpCustomerCredit(cust, amount);
                        StorageManager.saveUsers(MainApplication.userList);
                        showCustomMessageDialog("Success", "Top-up completed.", 400, 150);
                    } else {
                        showCustomMessageDialog("Error", "Customer not found.", 400, 150);
                    }
                } catch (NumberFormatException ex) {
                    showCustomMessageDialog("Error", "Invalid amount.", 400, 150);
                }
            }
        });

        // =====================
        // Generate Receipt Logic
        // =====================
        generateReceiptButton.addActionListener(e -> {
            String orderId = showCustomInputDialog("Generate Receipt", "Enter Order ID:", 400, 150);
            if (orderId != null && !orderId.trim().isEmpty()) {
                String receipt = admin.generateReceipt(orderId);
                if (receipt != null && !receipt.isEmpty()) {
                    showCustomMessageDialog("Receipt", receipt, 500, 300);
                } else {
                    showCustomMessageDialog("Receipt", "No receipt available.", 400, 150);
                }
            }
        });

        // =====================
        // Send Receipt Logic
        // =====================
        sendReceiptButton.addActionListener(e -> {
            String orderId = showCustomInputDialog("Send Receipt", "Enter Order ID:", 400, 150);
            if (orderId != null && !orderId.trim().isEmpty()) {
                admin.sendReceipt(orderId);
                showCustomMessageDialog("Success", "Receipt sent.", 400, 150);
            }
        });

        // =====================
        // Logout Logic
        // =====================
        logoutButton.addActionListener(e -> {
            MainApplication.currentUser = null;
            mainFrame.getMainPanel().removeAll();
            mainFrame.getMainPanel().add(new MainLoginDashboard(mainFrame), "Login");
            mainFrame.getCardLayout().show(mainFrame.getMainPanel(), "Login");
        });
    }

    /**
     * Helper method to create a styled button with rounded corners (for main buttons).
     */
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), BUTTON_CORNER_RADIUS, BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(BUTTON_SIZE, BUTTON_SIZE));
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(BUTTON_CORNER_RADIUS)); // Ensure MainBorder is defined or imported

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    /**
     * Helper method to create a smaller styled button for ButtonActions.
     */
    private JButton createDialogStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), DIALOG_BUTTON_CORNER_RADIUS, DIALOG_BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(DIALOG_BUTTON_WIDTH, DIALOG_BUTTON_HEIGHT));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(DIALOG_BUTTON_CORNER_RADIUS));

        // Hover effect for dialog buttons
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // =======================
    // Custom Dialog Helper Methods
    // =======================

    /**
     * Displays a custom message dialog with the given title and message.
     */
    private void showCustomMessageDialog(String title, String message, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setForeground(TEXT_COLOR);
        textArea.setBackground(BACKGROUND_COLOR);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(width - 50, height - 100));
        dialog.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton closeButton = createDialogStyledButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setMinimumSize(new Dimension(width, height));
        dialog.setResizable(true);
        dialog.pack();
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
    }

    /**
     * Displays a custom input dialog with the given title and message.
     * Returns the input string or null if cancelled.
     */
    private String showCustomInputDialog(String title, String message, int width, int height) {
        return showCustomInputDialog(title, message, "", width, height);
    }

    /**
     * Displays a custom input dialog with a default value.
     * Returns the input string or null if cancelled.
     */
    private String showCustomInputDialog(String title, String message, String defaultValue, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBackground(BACKGROUND_COLOR);
        JLabel label = new JLabel(message);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        inputPanel.add(label, BorderLayout.NORTH);
        JTextField textField = new JTextField(defaultValue, 20);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputPanel.add(textField, BorderLayout.CENTER);
        dialog.add(inputPanel, BorderLayout.CENTER);

        final String[] result = new String[1];
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton okButton = createDialogStyledButton("OK");
        JButton cancelButton = createDialogStyledButton("Cancel");

        okButton.addActionListener(e -> {
            result[0] = textField.getText();
            dialog.dispose();
        });
        cancelButton.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setMinimumSize(new Dimension(width, height));
        dialog.setResizable(true);
        dialog.pack();
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
        return result[0];
    }

    /**
     * Displays a custom selection dialog with the given title, message, and options.
     * Returns the selected option as a String or null if cancelled.
     */
    private String showCustomSelectionDialog(String title, String message, String[] options, int width, int height) {
        // If the provided width/height are too small, enforce bigger values:
        if (width < 400) width = 400;
        if (height < 200) height = 200;

        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        // Create a main panel with vertical layout to hold the selection and button panels
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Selection Panel
        JPanel selectionPanel = new JPanel(new BorderLayout(5, 5));
        selectionPanel.setBackground(BACKGROUND_COLOR);
        JLabel label = new JLabel(message);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        selectionPanel.add(label, BorderLayout.NORTH);

        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        selectionPanel.add(comboBox, BorderLayout.CENTER);

        mainPanel.add(selectionPanel);

        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        final String[] result = new String[1];
        JButton okButton = createDialogStyledButton("OK");
        JButton cancelButton = createDialogStyledButton("Cancel");

        okButton.addActionListener(e -> {
            result[0] = (String) comboBox.getSelectedItem();
            dialog.dispose();
        });
        cancelButton.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        mainPanel.add(buttonPanel);

        dialog.add(mainPanel, BorderLayout.CENTER);

        // Let layout managers size everything to fit
        dialog.pack();

        // Ensure the final dialog size is at least (width×height)
        dialog.setSize(
                Math.max(dialog.getWidth(), width),
                Math.max(dialog.getHeight(), height)
        );

        dialog.setResizable(true);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);

        return result[0];
    }
}
