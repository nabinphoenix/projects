package MainGUIOfSystem.Roles_of_Dashboards;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;

public class MainBorder extends AbstractBorder {
    private int radius;
    private int thickness;
    private Color borderColor;
    private Color focusBorderColor;

    /**
     * Creates a MainBorder with default thickness (1), base color (gray),
     * and focus color (cornflower blue).
     */
    public MainBorder(int radius) {
        this(radius, 1, Color.GRAY, new Color(100, 149, 237));
    }

    /**
     * Creates a MainBorder with custom parameters.
     *
     * @param radius           The radius for the rounded corners.
     * @param thickness        The thickness of the border.
     * @param borderColor      The base color of the border.
     * @param focusBorderColor The color used when the component is focused.
     */
    public MainBorder(int radius, int thickness, Color borderColor, Color focusBorderColor) {
        this.radius = radius;
        this.thickness = thickness;
        this.borderColor = borderColor;
        this.focusBorderColor = focusBorderColor;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // If the component is focused, use the focus color.
        Color currentColor = borderColor;
        if (c instanceof JComponent && ((JComponent) c).isFocusOwner()) {
            currentColor = focusBorderColor;
        }
        g2.setColor(currentColor);

        // Draw multiple rounds of the rounded rectangle to achieve the desired thickness.
        for (int i = 0; i < thickness; i++) {
            g2.drawRoundRect(x + i, y + i, width - 1 - 2 * i, height - 1 - 2 * i, radius, radius);
        }
        g2.dispose();
    }

    @Override
    public Insets getBorderInsets(Component c) {
        int inset = radius / 3 + thickness;
        return new Insets(inset, inset, inset, inset);
    }

    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        int inset = radius / 3 + thickness;
        insets.left = insets.top = insets.right = insets.bottom = inset;
        return insets;
    }
}
