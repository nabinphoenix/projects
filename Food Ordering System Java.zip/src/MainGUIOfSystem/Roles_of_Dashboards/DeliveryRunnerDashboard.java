package MainGUIOfSystem.Roles_of_Dashboards;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import MainGUIOfSystem.MainApplication;
import MainGUIOfSystem.ButtonActions.UpdateTaskStatus;
import Roles_and_Models.DeliveryRunner;
import Roles_and_Models.DeliveryTask;

public class DeliveryRunnerDashboard extends JPanel {
    private MainApplication mainFrame;
    private DeliveryRunner runner;

    // Colors for the GUI
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    // Main dashboard button dimensions and border radius
    private static final int BUTTON_WIDTH = 220;
    private static final int BUTTON_HEIGHT = 45;
    private static final int BUTTON_CORNER_RADIUS = 30;

    // Dialog button dimensions (increased size) and border radius
    private static final int DIALOG_BUTTON_WIDTH = 100;
    private static final int DIALOG_BUTTON_HEIGHT = 50;
    private static final int DIALOG_BUTTON_CORNER_RADIUS = 25;

    public DeliveryRunnerDashboard(MainApplication frame, DeliveryRunner runner) {
        this.mainFrame = frame;
        this.runner = runner;
        setLayout(new BorderLayout(10, 10));
        setBackground(BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Logo image on the top left
        ImageIcon logoIcon = new ImageIcon("src/DataStore_and_Images/logo.png");
        Image scaledLogoImage = logoIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogoImage));
        headerPanel.add(logoLabel, BorderLayout.WEST);

        // Runner image on the top right
        ImageIcon runnerIcon = new ImageIcon("src/DataStore_and_Images/Delivery Runner.png");
        Image scaledRunnerImage = runnerIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        JLabel runnerLogoLabel = new JLabel(new ImageIcon(scaledRunnerImage));
        headerPanel.add(runnerLogoLabel, BorderLayout.EAST);

        // Welcome message in the center
        JLabel welcomeLabel = new JLabel("Welcome, Delivery Runner: " + runner.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(TEXT_COLOR);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);
        add(headerPanel, BorderLayout.NORTH);

        // Button Panel using GridLayout (4 rows x 2 columns)
        JPanel buttonPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);

        JButton viewTasksButton = createStyledButton("View Available Tasks");
        JButton updateTaskButton = createStyledButton("Update Task Status");
        JButton viewTaskHistoryButton = createStyledButton("View Task History");
        JButton revenueDashboardButton = createStyledButton("Revenue Dashboard");
        JButton readCustomerReviewsButton = createStyledButton("Read Customer Reviews");

        buttonPanel.add(viewTasksButton);
        buttonPanel.add(updateTaskButton);
        buttonPanel.add(viewTaskHistoryButton);
        buttonPanel.add(revenueDashboardButton);
        buttonPanel.add(readCustomerReviewsButton);

        // Fill remaining grid cells to maintain layout
        for (int i = 5; i < 8; i++) {
            buttonPanel.add(new JLabel());
        }

        add(buttonPanel, BorderLayout.CENTER);

        // Logout Button placed at the bottom – increased size
        JButton logoutButton = createStyledButton("Logout");
        logoutButton.setPreferredSize(new Dimension(250, 55));
        add(logoutButton, BorderLayout.SOUTH);

        // Button Actions

        // 1. View Available Tasks: Display tasks assigned to the runner or available for pickup.
        viewTasksButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder("Available Tasks:\n");
            for (DeliveryTask task : MainApplication.deliveryTaskList) {
                if (task.getRunner() == null || task.getRunner().equals(runner)) {
                    sb.append("Task ID: ").append(task.getTaskId())
                            .append(" | Order ID: ").append(task.getOrder().getOrderId())
                            .append(" | Status: ").append(task.getStatus()).append("\n");
                }
            }
            if (sb.toString().equals("Available Tasks:\n")) {
                sb.append("No available tasks at the moment.");
            }
            showCustomMessageDialog("Available Tasks", sb.toString(), 500, 300);
        });

        // 2. Update Task Status: Open a dialog to update the status of a task.
        updateTaskButton.addActionListener(e -> {
            new UpdateTaskStatus(mainFrame, runner).setVisible(true);
        });

        // 3. View Task History: Display tasks completed by the runner.
        viewTaskHistoryButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder("Task History:\n");
            for (DeliveryTask task : runner.getTaskHistory()) {
                sb.append("Task ID: ").append(task.getTaskId())
                        .append(" | Order ID: ").append(task.getOrder().getOrderId())
                        .append(" | Status: ").append(task.getStatus()).append("\n");
            }
            if (sb.toString().equals("Task History:\n")) {
                sb.append("No task history available.");
            }
            showCustomMessageDialog("Task History", sb.toString(), 500, 300);
        });

        // 4. Revenue Dashboard: Display total earnings.
        revenueDashboardButton.addActionListener(e -> {
            double earnings = runner.getEarnings();
            showCustomMessageDialog("Revenue Dashboard", "Total Earnings: $" + String.format("%.2f", earnings), 400, 200);
        });

        // 5. Read Customer Reviews: Display reviews for the runner.
        readCustomerReviewsButton.addActionListener(e -> {
            // Get reviews filtered by role "DeliveryRunner"
            List<String> reviews = MainServices.ReviewReader.readReviewsForRole("src/DataStore_and_Images/reviews.txt", "DeliveryRunner");
            if (reviews.isEmpty()) {
                showCustomMessageDialog("Reviews", "No reviews found for your delivery runner.", 400, 150);
            } else {
                StringBuilder sb = new StringBuilder();
                // Process each review line
                for (String reviewLine : reviews) {
                    // Assuming the review file format is: CustomerName|SomeField|ReviewText|Role
                    String[] tokens = reviewLine.split("\\|");
                    if (tokens.length >= 3) {
                        String customerName = tokens[0].trim();
                        String reviewText = tokens[2].trim();
                        sb.append("Customer: ").append(customerName)
                                .append("\nReview: ").append(reviewText)
                                .append("\n\n");
                    }
                }
                showCustomMessageDialog("Customer Reviews", sb.toString(), 500, 300);
            }
        });



        // Logout: Reset current user and show login panel.
        logoutButton.addActionListener(e -> {
            MainApplication.currentUser = null;
            mainFrame.getMainPanel().removeAll();
            mainFrame.getMainPanel().add(new MainLoginDashboard(mainFrame), "Login");
            mainFrame.getCardLayout().show(mainFrame.getMainPanel(), "Login");
        });
    }

    // Helper: Create a styled button for the main dashboard.
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isPressed() ? getBackground().darker() : getBackground();
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), BUTTON_CORNER_RADIUS, BUTTON_CORNER_RADIUS);
                g2.dispose();

                FontMetrics fm = g.getFontMetrics();
                String txt = getText();
                int textWidth = fm.stringWidth(txt);
                int textHeight = fm.getAscent();
                int x = (getWidth() - textWidth) / 2;
                int y = (getHeight() + textHeight) / 2 - 2;
                g.setColor(getForeground());
                g.drawString(txt, x, y);

                if (isFocusOwner()) {
                    g.setColor(new Color(255, 255, 255, 128));
                    g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, BUTTON_CORNER_RADIUS, BUTTON_CORNER_RADIUS);
                }
            }
        };

        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setPreferredSize(new Dimension(BUTTON_WIDTH, BUTTON_HEIGHT));
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(new Color(100, 255, 100));
        button.setFocusPainted(false);
        button.setBorder(new RoundedBorder(BUTTON_CORNER_RADIUS));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_COLOR.brighter());
                button.setForeground(Color.WHITE);
                button.repaint();
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
                button.setForeground(new Color(100, 255, 100));
                button.repaint();
            }
        });
        return button;
    }

    // Helper: Create a smaller styled button for ButtonActions.
    private JButton createDialogStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isPressed() ? getBackground().darker() : getBackground();
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), DIALOG_BUTTON_CORNER_RADIUS, DIALOG_BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(DIALOG_BUTTON_WIDTH, DIALOG_BUTTON_HEIGHT));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new RoundedBorder(DIALOG_BUTTON_CORNER_RADIUS));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_COLOR.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // =======================
    // Custom Dialog Helper Methods
    // =======================

    /**
     * Displays a custom message dialog using a JDialog.
     */
    private void showCustomMessageDialog(String title, String message, int width, int height) {
        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setForeground(TEXT_COLOR);
        textArea.setBackground(BACKGROUND_COLOR);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(width - 50, height - 50));
        showCustomMessageDialog(title, scrollPane, width, height);
    }

    /**
     * Displays a custom message dialog using a JDialog with provided content.
     */
    private void showCustomMessageDialog(String title, JComponent content, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));
        content.setBackground(BACKGROUND_COLOR);
        dialog.add(content, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton closeButton = createDialogStyledButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setSize(width, height);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
    }

    // Custom Border class for rounded borders.
    private static class RoundedBorder implements javax.swing.border.Border {
        private int radius;
        RoundedBorder(int radius) {
            this.radius = radius;
        }
        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 1, radius + 1, radius + 1, radius + 1);
        }
        @Override
        public boolean isBorderOpaque() {
            return true;
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT_COLOR);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }
}
