package MainGUIOfSystem.Roles_of_Dashboards;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import MainGUIOfSystem.MainApplication;
import Roles_and_Models.User;
import SystemValidation.PasswordEncryptor;
import javax.crypto.SecretKey;
// Import the encryption class

public class MainLoginDashboard extends JPanel {
    private MainApplication mainFrame;
    private JTextField emailField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel logoLabel;

    private Color backgroundColor = new Color(9, 0, 7); // Black
    private Color textColor = new Color(100, 255, 100); // Green
    private Color buttonColor = new Color(128, 0, 128); // Purple
    private Color hoverButtonColor = new Color(147, 0, 147); // Slightly lighter purple
    private Color fieldBackgroundColor = new Color(20, 20, 20); // Dark Gray

    public MainLoginDashboard(MainApplication frame) {
        this.mainFrame = frame;
        setLayout(null);
        setBackground(backgroundColor);

        // *Load and Resize Logo*
        ImageIcon originalIcon = new ImageIcon("src/DataStore_and_Images/logo.png");
        Image scaledImage = originalIcon.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH);
        logoLabel = new JLabel(new ImageIcon(scaledImage));
        logoLabel.setBounds(320, 20, 180, 180); // Centered logo
        add(logoLabel);

        // *Title Label*
        JLabel titleLabel = new JLabel("Login Dashboard", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(textColor);
        titleLabel.setBounds(200, 210, 400, 50);
        add(titleLabel);


        // Load and set the icon for the frame
        try {
            BufferedImage img = ImageIO.read(new File("src/DataStore_and_Images/logo.png"));
            mainFrame.setIconImage(img); // Set icon on the main frame instead of JPanel
        } catch (IOException e) {
            System.err.println("Error loading logo: " + e.getMessage());
        }


        // *Email Label & Field*
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        emailLabel.setForeground(textColor);
        emailLabel.setBounds(230, 280, 100, 30);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(330, 280, 220, 35);
        emailField.setBackground(fieldBackgroundColor);
        emailField.setForeground(textColor);
        emailField.setCaretColor(textColor);
        emailField.setBorder(BorderFactory.createLineBorder(textColor, 2));
        add(emailField);

        addFieldHoverEffect(emailField);

        // *Password Label & Field*
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        passLabel.setForeground(textColor);
        passLabel.setBounds(230, 330, 100, 30);
        add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(330, 330, 220, 35);
        passwordField.setBackground(fieldBackgroundColor);
        passwordField.setForeground(textColor);
        passwordField.setCaretColor(textColor);
        passwordField.setBorder(BorderFactory.createLineBorder(textColor, 2));
        add(passwordField);

        addFieldHoverEffect(passwordField);

        // *Login Button*
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 18));
        loginButton.setBackground(buttonColor);
        loginButton.setForeground(Color.WHITE);
        loginButton.setBounds(290, 400, 220, 45);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setOpaque(true);
        loginButton.setBorderPainted(false);
        loginButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        // *Hover Effect on Button*
        loginButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(hoverButtonColor);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                loginButton.setBackground(buttonColor);
            }
        });

        add(loginButton);

        // *Login Button Action*
        loginButton.addActionListener(e -> {
            String email = emailField.getText().trim();
            String pass = new String(passwordField.getPassword());
            boolean found = false;

            // Load the encryption key
            SecretKey secretKey = null;
            try {
                secretKey = PasswordEncryptor.loadKey();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(MainLoginDashboard.this, "Error loading encryption key", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Encrypt the input password
            String encryptedInputPassword = null;
            try {
                encryptedInputPassword = PasswordEncryptor.encrypt(pass, secretKey);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(MainLoginDashboard.this, "Error encrypting password", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            for (User u : MainApplication.userList) {
                if (u.getEmail().equalsIgnoreCase(email) && u.getPassword().equals(encryptedInputPassword)) {
                    MainApplication.currentUser = u;
                    found = true;
                    break;
                }
            }

            if (found) {
                JOptionPane.showMessageDialog(MainLoginDashboard.this, "Login successful as " +
                        MainApplication.currentUser.getName() + " (" + MainApplication.currentUser.getRole() + ")");
                mainFrame.switchToUserPanel();
            } else {
                JOptionPane.showMessageDialog(MainLoginDashboard.this, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void addFieldHoverEffect(JTextField field) {
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                field.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
            }
            @Override
            public void focusLost(FocusEvent e) {
                field.setBorder(BorderFactory.createLineBorder(textColor, 2));
            }
        });
    }
}
