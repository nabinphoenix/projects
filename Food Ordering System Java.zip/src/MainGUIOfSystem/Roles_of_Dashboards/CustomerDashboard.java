package MainGUIOfSystem.Roles_of_Dashboards;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import MainGUIOfSystem.ButtonActions.ReorderDialog;
import MainGUIOfSystem.MainApplication;
import MainGUIOfSystem.ButtonActions.CancelOrder;
import MainGUIOfSystem.ButtonActions.PlaceOrderDialog;
import MainServices.Notification;
import Roles_and_Models.Customer;
import Roles_and_Models.FoodItem;
import Roles_and_Models.Vendor;
import Roles_and_Models.DeliveryTask;
import Roles_and_Models.Order;
import Roles_and_Models.OrderStatus;
import MainServices.ReviewManager;

public class CustomerDashboard extends JPanel {
    private MainApplication mainFrame;
    private Customer customer;
    private JLabel creditLabel;

    // Constants for colors
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    // Constants for spacing
    private static final int BORDER_SIZE = 19;
    private static final int INSET_SIZE = 5;
    private static final int VERTICAL_STRUT_SIZE = 10;

    // Constants for main button size and border radius
    private static final int BUTTON_SIZE = 100;
    private static final int BUTTON_CORNER_RADIUS = 30;

    // Constants for image size
    private static final int IMAGE_WIDTH = 50;
    private static final int IMAGE_HEIGHT = 50;

    // Constants for dialog button size and border radius (smaller than main buttons)
    private static final int DIALOG_BUTTON_WIDTH = 80;
    private static final int DIALOG_BUTTON_HEIGHT = 40;
    private static final int DIALOG_BUTTON_CORNER_RADIUS = 20;

    // Constructor now only accepts the main frame.
    public CustomerDashboard(MainApplication frame, Customer currentUser) {
        this.mainFrame = frame;
        // Read customer data directly from file.
        this.customer = currentUser; // Use the provided user
        initComponents();
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBackground(BACKGROUND_COLOR);
        setBorder(BorderFactory.createEmptyBorder(BORDER_SIZE, BORDER_SIZE, BORDER_SIZE, BORDER_SIZE));

        // Main panel with GridBagLayout
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(INSET_SIZE, INSET_SIZE, INSET_SIZE, INSET_SIZE);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.weighty = 0.0;

        // Header with images and welcome message
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(BACKGROUND_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Logo image in the top-left corner
        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS)); // Vertical alignment
        logoPanel.setBackground(BACKGROUND_COLOR);

        ImageIcon logoIcon = new ImageIcon("src/DataStore_and_Images/logo.png");
        Image scaledLogoImage = logoIcon.getImage().getScaledInstance(IMAGE_WIDTH, IMAGE_HEIGHT, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledLogoImage));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Center the logo

        // Adding spacing between logo and credit label
        logoPanel.add(logoLabel);
        logoPanel.add(Box.createVerticalStrut(VERTICAL_STRUT_SIZE)); // Space of 10 pixels

        // Credit Balance Label
        creditLabel = new JLabel("Credit Balance: $" + customer.getCreditBalance());
        creditLabel.setFont(new Font("Arial", Font.BOLD, 14));
        creditLabel.setForeground(TEXT_COLOR);
        creditLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Center the label

        logoPanel.add(creditLabel);
        headerPanel.add(logoPanel, BorderLayout.WEST);

        // Customer image in the top-right corner
        ImageIcon customerIcon = new ImageIcon("src/DataStore_and_Images/Customer.png");
        Image scaledCustomerImage = customerIcon.getImage().getScaledInstance(IMAGE_WIDTH, IMAGE_HEIGHT, Image.SCALE_SMOOTH);
        JLabel customerLabel = new JLabel(new ImageIcon(scaledCustomerImage));
        headerPanel.add(customerLabel, BorderLayout.EAST);

        JLabel welcomeLabel = new JLabel("Welcome,Customer: " + customer.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));
        welcomeLabel.setForeground(TEXT_COLOR);
        headerPanel.add(welcomeLabel, BorderLayout.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        mainPanel.add(headerPanel, gbc);

        // Button panel using GridLayout
        JPanel buttonPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        buttonPanel.setBackground(BACKGROUND_COLOR);

        JButton viewMenuButton = createStyledButton("View Menu");
        JButton placeOrderButton = createStyledButton("Place Order");
        JButton checkOrderStatusButton = createStyledButton("Check Order Status");
        JButton cancelOrderButton = createStyledButton("Cancel Order");
        JButton reorderButton = createStyledButton("Reorder");
        JButton orderHistoryButton = createStyledButton("Order History");
        JButton transactionHistoryButton = createStyledButton("Transaction History");
        JButton provideReviewButton = createStyledButton("Provide Review");
        JButton readReviewsButton = createStyledButton("Read Reviews");
        JButton viewNotificationsButton = createStyledButton("View Notifications");

        buttonPanel.add(viewMenuButton);
        buttonPanel.add(placeOrderButton);
        buttonPanel.add(cancelOrderButton);
        buttonPanel.add(checkOrderStatusButton);
        buttonPanel.add(reorderButton);
        buttonPanel.add(orderHistoryButton);
        buttonPanel.add(transactionHistoryButton);
        buttonPanel.add(provideReviewButton);
        buttonPanel.add(readReviewsButton);
        buttonPanel.add(viewNotificationsButton);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // Logout Button at the bottom
        JButton logoutButton = createStyledButton("Logout");
        add(logoutButton, BorderLayout.SOUTH);

        // ----------------------
        // Button Actions
        // ----------------------

        // View Menu Action
        viewMenuButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Roles_and_Models.User u : MainApplication.userList) {
                if (u instanceof Vendor) {
                    Vendor vend = (Vendor) u;
                    sb.append("Vendor: ").append(vend.getName()).append("\n");
                    for (FoodItem item : vend.getMenu()) {
                        sb.append("  ").append(item.toString()).append("\n");
                    }
                    sb.append("\n");
                }
            }
            showCustomMessageDialog("Menu", sb.toString(), 500, 300);
        });

        // Place Order Action
        placeOrderButton.addActionListener(e -> {
            PlaceOrderDialog placeOrderDialog = new PlaceOrderDialog(mainFrame, customer);
            placeOrderDialog.setVisible(true);
            updateCreditLabel();
        });

        // Cancel Order Action
        cancelOrderButton.addActionListener(e -> new CancelOrder(mainFrame, customer).setVisible(true));

        // Check Order Status Action
        checkOrderStatusButton.addActionListener(e -> {
            if (customer.getOrderHistory().isEmpty()) {
                showCustomMessageDialog("Order Status", "No orders found.", 400, 200);
                return;
            }
            StringBuilder statusSb = new StringBuilder("Your Orders:\n\n");
            for (Order order : customer.getOrderHistory()) {
                statusSb.append("Order ID: ").append(order.getOrderId())
                        .append(" - Status: ").append(order.getStatus())
                        .append("\n");
            }
            showCustomMessageDialog("Order Status", statusSb.toString(), 500, 300);
        });

        // Reorder Action
        reorderButton.addActionListener(e -> new ReorderDialog(mainFrame, customer).setVisible(true));

        // Order History Action
        orderHistoryButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (Order o : customer.getOrderHistory()) {
                sb.append(o.toString()).append("\n");
            }
            showCustomMessageDialog("Order History", sb.toString(), 500, 300);
        });

        // Transaction History Action
        transactionHistoryButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            sb.append("Transaction History for ").append(customer.getName()).append("\n\n");
            sb.append("Order ID\t\tAmount\t\tStatus\n");
            sb.append("--------------------------------------------------\n");

            if (customer.getOrderHistory().isEmpty()) {
                sb.append("No transactions found.\n");
            } else {
                for (Order order : customer.getOrderHistory()) {
                    sb.append(order.getOrderId()).append("\t\t");
                    sb.append("$").append(String.format("%.2f", order.getTotalAmount())).append("\t\t");
                    sb.append(order.getStatus()).append("\n");
                }
            }
            showCustomMessageDialog("Transaction History", sb.toString(), 550, 350);
        });

        provideReviewButton.addActionListener(e -> {
            if (customer.getOrderHistory().isEmpty()) {
                showCustomMessageDialog("No Orders", "You have no orders to review.", 400, 200);
                return;
            }
            JDialog reviewDialog = new JDialog(mainFrame, "Provide Reviews", true);
            reviewDialog.getContentPane().setBackground(BACKGROUND_COLOR);
            reviewDialog.setLayout(new BorderLayout(10, 10));
            reviewDialog.setSize(500, 400);
            reviewDialog.setLocationRelativeTo(mainFrame);
            JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            topPanel.setBackground(BACKGROUND_COLOR);
            topPanel.add(new JLabel("Select Order:"));
            JComboBox<Order> orderComboBox = new JComboBox<>();
            for (Order order : customer.getOrderHistory()) {
                if (order.getStatus() == OrderStatus.ACCEPTED ||
                        order.getStatus() == OrderStatus.DELIVERED) {
                    orderComboBox.addItem(order);
                }
            }
            topPanel.add(orderComboBox);
            reviewDialog.add(topPanel, BorderLayout.NORTH);
            JPanel reviewPanel = new JPanel();
            reviewPanel.setBackground(BACKGROUND_COLOR);
            reviewPanel.setLayout(new BoxLayout(reviewPanel, BoxLayout.Y_AXIS));
            JPanel vendorPanel = new JPanel(new BorderLayout(5, 5));
            vendorPanel.setBackground(BACKGROUND_COLOR);
            vendorPanel.add(new JLabel("Vendor Review:"), BorderLayout.NORTH);
            JTextArea vendorReviewArea = new JTextArea(4, 30);
            vendorReviewArea.setLineWrap(true);
            vendorReviewArea.setWrapStyleWord(true);
            vendorPanel.add(new JScrollPane(vendorReviewArea), BorderLayout.CENTER);
            JPanel runnerPanel = new JPanel(new BorderLayout(5, 5));
            runnerPanel.setBackground(BACKGROUND_COLOR);
            runnerPanel.add(new JLabel("Delivery Runner Review:"), BorderLayout.NORTH);
            JTextArea runnerReviewArea = new JTextArea(4, 30);
            runnerReviewArea.setLineWrap(true);
            runnerReviewArea.setWrapStyleWord(true);
            runnerPanel.add(new JScrollPane(runnerReviewArea), BorderLayout.CENTER);
            reviewPanel.add(vendorPanel);
            reviewPanel.add(Box.createVerticalStrut(10));
            reviewPanel.add(runnerPanel);
            reviewDialog.add(reviewPanel, BorderLayout.CENTER);
            JButton submitButton = createDialogStyledButton("Submit Reviews");
            submitButton.addActionListener(ev -> {
                Order selectedOrder = (Order) orderComboBox.getSelectedItem();
                if (selectedOrder == null) {
                    showCustomMessageDialog("Error", "Please select an order.", 400, 200);
                    return;
                }
                String vendorReviewText = vendorReviewArea.getText().trim();
                String runnerReviewText = runnerReviewArea.getText().trim();
                boolean submittedAny = false;
                if (!vendorReviewText.isEmpty()) {
                    if (selectedOrder.getStatus() == OrderStatus.ACCEPTED ||
                            selectedOrder.getStatus() == OrderStatus.DELIVERED) {
                        ReviewManager.saveReview(
                                customer.getName(),
                                selectedOrder.getVendor().getName(),
                                vendorReviewText,
                                "Vendor"
                        );
                        submittedAny = true;
                    } else {
                        showCustomMessageDialog("Error", "This order is not eligible for vendor review.", 400, 200);
                        return;
                    }
                }
                if (!runnerReviewText.isEmpty()) {
                    if (selectedOrder.getStatus() == OrderStatus.ACCEPTED ||
                            selectedOrder.getStatus() == OrderStatus.DELIVERED) {
                        DeliveryTask task = findDeliveryTaskForOrder(selectedOrder);
                        String runnerName = "Unknown Runner";
                        if (task != null && task.getRunner() != null) {
                            runnerName = task.getRunner().getName();
                        }
                        ReviewManager.saveReview(
                                customer.getName(),
                                runnerName,
                                runnerReviewText,
                                "DeliveryRunner"
                        );
                        submittedAny = true;
                    } else {
                        showCustomMessageDialog("Error", "This order is not eligible for delivery runner review.", 400, 200);
                        return;
                    }
                }
                if (!submittedAny) {
                    showCustomMessageDialog("Error", "Please enter at least one review.", 400, 200);
                    return;
                }
                showCustomMessageDialog("Success", "Thank you for your reviews!", 400, 200);
                reviewDialog.dispose();
            });
            reviewDialog.add(submitButton, BorderLayout.SOUTH);
            reviewDialog.setVisible(true);
        });
        readReviewsButton.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            List<String> vendorReviews = new ArrayList<>();
            List<String> runnerReviews = new ArrayList<>();
            try {
                List<String> lines = Files.readAllLines(
                        Paths.get("src/DataStore_and_Images/reviews.txt"),
                        StandardCharsets.UTF_8
                );
                for (String line : lines) {
                    String[] parts = line.split("\\|");
                    if (parts.length == 4) {
                        String reviewType = parts[3].trim();
                        if ("Vendor".equalsIgnoreCase(reviewType)) {
                            vendorReviews.add(parts[1].trim() + ": " + parts[2].trim());
                        } else if ("DeliveryRunner".equalsIgnoreCase(reviewType)) {
                            runnerReviews.add(parts[1].trim() + ": " + parts[2].trim());
                        }
                    }
                }
            } catch (IOException ex) {
                sb.append("Error reading reviews: ").append(ex.getMessage());
            }
            sb.append("*********** Vendor Reviews ***********\n");
            if (vendorReviews.isEmpty()) {
                sb.append("No vendor reviews found.\n");
            } else {
                for (String review : vendorReviews) {
                    sb.append(review).append("\n\n");
                }
            }
            sb.append("*********** Delivery Runner Reviews ***********\n");
            if (runnerReviews.isEmpty()) {
                sb.append("No delivery runner reviews found.\n");
            } else {
                for (String review : runnerReviews) {
                    sb.append(review).append("\n\n");
                }
            }
            showCustomMessageDialog("Read Reviews", sb.toString(), 500, 300);
        });


        // View Notifications Action
        viewNotificationsButton.addActionListener(e -> {
            List<String> notifications = Notification.readNotifications(customer.getName());
            if (notifications.isEmpty()) {
                showCustomMessageDialog("Notifications", "No notifications available.", 400, 200);
            } else {
                StringBuilder notifText = new StringBuilder();
                for (String notif : notifications) {
                    notifText.append(notif).append("\n\n");
                }
                showCustomMessageDialog("Notifications", notifText.toString(), 500, 200);
            }
        });

        // Logout Action
        logoutButton.addActionListener(e -> {
            MainApplication.currentUser = null;
            mainFrame.getMainPanel().removeAll();
            mainFrame.getMainPanel().add(new MainLoginDashboard(mainFrame), "Login");
            mainFrame.getCardLayout().show(mainFrame.getMainPanel(), "Login");
        });
    }

    // Helper: find DeliveryTask for a given order
    private DeliveryTask findDeliveryTaskForOrder(Order order) {
        List<DeliveryTask> deliveryTasks = mainFrame.getDeliveryTasks();
        for (DeliveryTask task : deliveryTasks) {
            if (task.getOrder() != null && task.getOrder().getOrderId().equals(order.getOrderId())) {
                return task;
            }
        }
        return null;
    }

    // Helper: Update Credit Label
    public void updateCreditLabel() {
        creditLabel.setText("Credit Balance: $" + customer.getCreditBalance());
        creditLabel.revalidate();
        creditLabel.repaint();
    }

    // Helper: Create a Styled Button with a rounded border and fixed size for main dashboard buttons
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), BUTTON_CORNER_RADIUS, BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(BUTTON_SIZE, BUTTON_SIZE));
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(BUTTON_CORNER_RADIUS)); // Ensure MainBorder is defined or imported

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // Helper: Create a smaller styled button for ButtonActions
    private JButton createDialogStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), DIALOG_BUTTON_CORNER_RADIUS, DIALOG_BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(DIALOG_BUTTON_WIDTH, DIALOG_BUTTON_HEIGHT));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new MainBorder(DIALOG_BUTTON_CORNER_RADIUS)); // Ensure MainBorder is defined or imported

        // Hover effect for dialog buttons
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(button.getBackground().brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // =======================
    // Custom Dialog Helper Methods
    // =======================

    /**
     * Displays a custom message dialog using a JDialog.
     */
    private void showCustomMessageDialog(String title, JComponent content, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));
        content.setBackground(BACKGROUND_COLOR);
        dialog.add(content, BorderLayout.CENTER);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton closeButton = createDialogStyledButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        dialog.setSize(width, height);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
    }

    /**
     * Overloaded method for displaying a simple text message in a custom dialog.
     */
    private void showCustomMessageDialog(String title, String message, int width, int height) {
        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setForeground(TEXT_COLOR);
        textArea.setBackground(BACKGROUND_COLOR);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(width - 50, height - 50));
        showCustomMessageDialog(title, scrollPane, width, height);
    }

    /**
     * Displays a custom input dialog with the given title and message.
     * Returns the input string or null if cancelled.
     */
    private String showCustomInputDialog(String title, String message, int width, int height) {
        return showCustomInputDialog(title, message, "", width, height);
    }

    /**
     * Displays a custom input dialog with a default value.
     * Returns the input string or null if cancelled.
     */
    private String showCustomInputDialog(String title, String message, String defaultValue, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBackground(BACKGROUND_COLOR);
        JLabel label = new JLabel(message);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        inputPanel.add(label, BorderLayout.NORTH);
        JTextField textField = new JTextField(defaultValue, 20);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        inputPanel.add(textField, BorderLayout.CENTER);
        dialog.add(inputPanel, BorderLayout.CENTER);

        final String[] result = new String[1];
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton okButton = createDialogStyledButton("OK");
        JButton cancelButton = createDialogStyledButton("Cancel");

        okButton.addActionListener(e -> {
            result[0] = textField.getText();
            dialog.dispose();
        });
        cancelButton.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setSize(width, height);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
        return result[0];
    }

    /**
     * Displays a custom selection dialog with the given title, message, and options.
     * Returns the selected option as a String or null if cancelled.
     */
    private String showCustomSelectionDialog(String title, String message, String[] options, int width, int height) {
        JDialog dialog = new JDialog(mainFrame, title, true);
        dialog.getContentPane().setBackground(BACKGROUND_COLOR);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel selectionPanel = new JPanel(new BorderLayout(5, 5));
        selectionPanel.setBackground(BACKGROUND_COLOR);
        JLabel label = new JLabel(message);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        selectionPanel.add(label, BorderLayout.NORTH);

        JComboBox<String> comboBox = new JComboBox<>(options);
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        selectionPanel.add(comboBox, BorderLayout.CENTER);
        dialog.add(selectionPanel, BorderLayout.CENTER);

        final String[] result = new String[1];
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        JButton okButton = createDialogStyledButton("OK");
        JButton cancelButton = createDialogStyledButton("Cancel");

        okButton.addActionListener(e -> {
            result[0] = (String) comboBox.getSelectedItem();
            dialog.dispose();
        });
        cancelButton.addActionListener(e -> {
            result[0] = null;
            dialog.dispose();
        });
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        dialog.setSize(width, height);
        dialog.setLocationRelativeTo(mainFrame);
        dialog.setVisible(true);
        return result[0];
    }

    // Helper: Read a Customer record from users.txt
    private Customer readCustomerFromFile() {
        String filePath = "src/DataStore_and_Images/users.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Expected CSV format: id,name,email,password,role,credit
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    String id = parts[0].trim();
                    String name = parts[1].trim();
                    String email = parts[2].trim();
                    String password = parts[3].trim();
                    String role = parts[4].trim();
                    double credit = Double.parseDouble(parts[5].trim());
                    if (role.equalsIgnoreCase("Customer")) {
                        return new Customer(id, name, email, password, credit);
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return null;
    }
}
