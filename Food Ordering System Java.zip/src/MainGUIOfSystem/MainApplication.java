package MainGUIOfSystem;

import MainGUIOfSystem.Roles_of_Dashboards.*;
import Roles_and_Models.*;
import MainServices.StorageManager;
import SystemValidation.PasswordEncryptor;  // Import the encryption class

import javax.crypto.SecretKey;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainApplication extends JFrame {
    private List<DeliveryTask> deliveryTasks = new ArrayList<>();
    // Global in-memory lists
    public static List<User> userList = new ArrayList<>();
    public static List<Order> orderList = new ArrayList<>();
    public static List<DeliveryTask> deliveryTaskList = new ArrayList<>();
    public static User currentUser = null;

    // For CSV lookups when loading orders
    public static Map<String, Customer> customerMap = new HashMap<>();
    public static Map<String, Vendor> vendorMap = new HashMap<>();
    public static Map<String, FoodItem> foodItemMap = new HashMap<>();
    public static Map<String, Order> orderMap = new HashMap<>();
    public static Map<String, DeliveryRunner> runnerMap = new HashMap<>();

    private CardLayout cardLayout;
    private JPanel mainPanel;

    public MainApplication() {
        setTitle("University Food Ordering System");
        setSize(800,600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Load persistent DataStore_and_Images (users, menus, orders)
        loadPersistentData();

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.add(new MainLoginDashboard(this), "Login");
        add(mainPanel);
        cardLayout.show(mainPanel, "Login");
    }

    // Getter methods for CardLayout and mainPanel
    public JPanel getMainPanel() {
        return mainPanel;
    }
    public CardLayout getCardLayout() {
        return cardLayout;
    }

    // Load persistent DataStore_and_Images from text files and reconstruct in-memory lists.
    private void loadPersistentData() {
        // Load users from file
        userList = StorageManager.loadUsers();

        // Integrate encryption: if no users exist, create a default admin with an encrypted password.
        if (userList.isEmpty()) {
            SecretKey secretKey = null;
            try {
                // Try to load an existing key, or generate one if it doesn't exist.
                secretKey = PasswordEncryptor.loadKey();
            } catch (Exception e) {
                try {
                    secretKey = PasswordEncryptor.generateKey();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            String encryptedAdminPassword = "A@dmin123";
            try {
                encryptedAdminPassword = PasswordEncryptor.encrypt("A@dmin123", secretKey);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Administrator admin = new Administrator("A001", "NABIN NEPALI", "admin01@gmail.com", encryptedAdminPassword);
            userList.add(admin);
            StorageManager.saveUsers(userList);
        } else {
            // Optionally: iterate through the userList and (if needed) re-encrypt passwords that are still in plaintext.
            // This requires logic to detect if a password is already encrypted.
            // For now, we assume that all users loaded are already processed.
        }

        // Build lookup maps.
        customerMap.clear();
        vendorMap.clear();
        runnerMap.clear();
        for (User u : userList) {
            if (u instanceof Customer) {
                customerMap.put(u.getId(), (Customer) u);
            } else if (u instanceof Vendor) {
                vendorMap.put(u.getId(), (Vendor) u);
            } else if (u instanceof DeliveryRunner) {
                runnerMap.put(u.getId(), (DeliveryRunner) u);
            }
        }

        // Load menus and assign FoodItems to Vendors.
        StorageManager.loadMenus(userList);

        // Build a global foodItemMap (for lookup by itemId)
        foodItemMap.clear();
        for (Vendor v : vendorMap.values()) {
            for (FoodItem fi : v.getMenu()) {
                foodItemMap.put(fi.getItemId(), fi);
            }
        }

        // Load orders
        orderList = StorageManager.loadOrders(customerMap, vendorMap, foodItemMap);

        // Build order lookup map
        orderMap.clear();
        for (Order o : orderList) {
            orderMap.put(o.getOrderId(), o);

            // Ensure vendor is not null before adding order
            if (o.getVendor() != null) {
                o.getVendor().addOrder(o);
            } else {
                System.err.println("Warning: Order " + o.getOrderId() + " has no associated vendor.");
            }

            // Ensure customer is not null before adding to order history
            if (o.getCustomer() != null) {
                o.getCustomer().addOrderHistory(o);
            } else {
                System.err.println("Warning: Order " + o.getOrderId() + " has no associated customer.");
            }
        }
    }

    // Switch Roles_of_Dashboards based on user role.
    public void switchToUserPanel() {
        if (currentUser instanceof Administrator) {
            mainPanel.add(new AdminDashboard(this, (Administrator) currentUser), "Admin");
            cardLayout.show(mainPanel, "Admin");
        } else if (currentUser instanceof Customer) {
            mainPanel.add(new CustomerDashboard(this, (Customer) currentUser), "Customer");
            cardLayout.show(mainPanel, "Customer");
        } else if (currentUser instanceof Vendor) {
            mainPanel.add(new VendorDashboard(this, (Vendor) currentUser), "Vendor");
            cardLayout.show(mainPanel, "Vendor");
        } else if (currentUser instanceof DeliveryRunner) {
            mainPanel.add(new DeliveryRunnerDashboard(this, (DeliveryRunner) currentUser), "Runner");
            cardLayout.show(mainPanel, "Runner");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainApplication().setVisible(true));
    }

    public void logout() {
        this.dispose();
    }

    public List<DeliveryTask> getDeliveryTasks() {
        return deliveryTasks;
    }

    public void showLoginPanel() {
    }
    /**
     * Retrieves an order by its ID.
     *
     * @param orderId The ID of the order to retrieve.
     * @return The Order object, or null if not found.
     */
    public static Order getOrderById(String orderId) {
        if (orderId == null || orderId.trim().isEmpty()) {
            return null;
        }
        return orderMap.get(orderId);
    }

    /**
     * Retrieves a user by their ID.
     *
     * @param userId The ID of the user to retrieve.
     * @return The User object, or null if not found.
     */
    public static User getUserById(String userId) {
        if (userId == null || userId.trim().isEmpty()) {
            return null;
        }
        for (User user : userList) {
            if (user.getId().equals(userId)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Returns the list of users.
     *
     * @return The list of users.
     */
    public static List<User> getUserList() {
        return userList;
    }

}
