package MainGUIOfSystem.ButtonActions;

import MainGUIOfSystem.MainApplication;
import Roles_and_Models.*;
import MainServices.Payment;
import MainServices.StorageManager;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class ReorderDialog extends JDialog {

    // ---------------------- Color and Style Constants ----------------------
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR       = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR     = new Color(128, 0, 128);
    private static final int CORNER_RADIUS        = 20;

    // ---------------------- Instance Variables ----------------------
    private JComboBox<String> orderBox;
    private JButton reorderButton;
    private Customer customer;
    private MainApplication mainFrame;

    // ---------------------- Constructor ----------------------
    public ReorderDialog(MainApplication frame, Customer customer) {
        super(frame, "Reorder from History", true);
        this.mainFrame = frame;
        this.customer = customer;

        // Set up dialog properties
        setSize(400, 250);
        setLocationRelativeTo(frame);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(BACKGROUND_COLOR);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ---------------------- Label ----------------------
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(createStyledLabel("Select Order to Reorder:"), gbc);

        // ---------------------- Fetch Order History ----------------------
        ArrayList<Order> history = new ArrayList<>(customer.getOrderHistory());
        if (history.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No previous orders to reorder.", "Error", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // Populate order IDs from history
        String[] orderIds = new String[history.size()];
        for (int i = 0; i < history.size(); i++) {
            orderIds[i] = history.get(i).getOrderId();
        }

        // ---------------------- Combo Box ----------------------
        orderBox = createStyledComboBox(orderIds);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(orderBox, gbc);

        // ---------------------- Reorder Button ----------------------
        reorderButton = createStyledButton("Reorder");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(reorderButton, gbc);

        // ---------------------- Button Action ----------------------
        reorderButton.addActionListener(e -> {
            int index = orderBox.getSelectedIndex();
            if (index < 0 || index >= history.size()) {
                JOptionPane.showMessageDialog(ReorderDialog.this, "Invalid selection", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Order oldOrder = history.get(index);
            String newOrderId = "ORD" + (MainApplication.orderList.size() + 1);
            Order newOrder = new Order(newOrderId, customer, oldOrder.getVendor(), oldOrder.getItems(), OrderStatus.PENDING, oldOrder.getOrderType());
            if (newOrder.getOrderType() == OrderType.DELIVERY) {
                newOrder.setDeliveryFee(2.50);
            }
            double totalAmount = newOrder.getTotalAmount();
            if (Payment.processPayment(customer, totalAmount)) {
                MainApplication.orderList.add(newOrder);
                customer.addOrderHistory(newOrder);
                oldOrder.getVendor().addOrder(newOrder);
                StorageManager.saveOrders(MainApplication.orderList);
                StorageManager.saveUsers(MainApplication.userList);
                JOptionPane.showMessageDialog(ReorderDialog.this, "Reorder placed with Order ID: " + newOrderId);
                if (newOrder.getOrderType() == OrderType.DELIVERY) {
                    DeliveryTask dt = findDeliveryTask(newOrder);
                    if (dt == null) {
                        String taskId = "TASK" + (MainApplication.deliveryTaskList.size() + 1);
                        dt = new DeliveryTask(taskId, newOrder, null, "Pending");
                        MainApplication.deliveryTaskList.add(dt);
                    }
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(ReorderDialog.this, "Payment failed", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    // ---------------------- Helper Methods ----------------------
    private DeliveryTask findDeliveryTask(Order order) {
        for (DeliveryTask dt : MainApplication.deliveryTaskList) {
            if (dt.getOrder().equals(order))
                return dt;
        }
        return null;
    }

    // Create a styled label with green text and a bold font.
    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        return label;
    }

    // Create a styled combo box with a dark background, green text, and a border.
    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        comboBox.setBackground(BACKGROUND_COLOR.darker());
        comboBox.setForeground(TEXT_COLOR);
        comboBox.setBorder(BorderFactory.createLineBorder(TEXT_COLOR, 2));
        comboBox.setPreferredSize(new Dimension(250, 30));
        return comboBox;
    }

    // Create a styled button with rounded corners, purple background, green text, and a hover effect.
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), CORNER_RADIUS, CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new RoundedBorder(CORNER_RADIUS));
        button.setPreferredSize(new Dimension(250, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect: brighten the button on mouse enter
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_COLOR.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // Custom rounded border for buttons
    private static class RoundedBorder implements Border {
        private final int radius;
        public RoundedBorder(int radius) {
            this.radius = radius;
        }
        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 1, radius + 1, radius + 1, radius + 1);
        }
        @Override
        public boolean isBorderOpaque() {
            return false;
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT_COLOR);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }
    }
}
