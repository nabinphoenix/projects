package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Roles_and_Models.Vendor;
import Roles_and_Models.FoodItem;
import MainGUIOfSystem.MainApplication;
import MainServices.StorageManager;

public class AddMenuItem extends JDialog {
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    private JTextField itemIdField, nameField, priceField;
    private JButton addButton;
    private Vendor vendor;

    public AddMenuItem(MainApplication frame, Vendor vendor) {
        super(frame, "Add Food Item", true);
        this.vendor = vendor;

        // Set Dialog Properties
        setSize(420, 300);
        setLocationRelativeTo(frame);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(BACKGROUND_COLOR);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Title Label
        JLabel titleLabel = new JLabel("Add a New Food Item");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(TEXT_COLOR);
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(titleLabel, gbc);

        // Item ID
        addLabel("Item ID:", gbc, 1);
        itemIdField = createTextField(gbc);

        // Name
        addLabel("Name:", gbc, 2);
        nameField = createTextField(gbc);

        // Price
        addLabel("Price:", gbc, 3);
        priceField = createTextField(gbc);

        // Add Button
        addButton = createButton("Add");
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(addButton, gbc);

        addButton.addActionListener(e -> addFoodItem());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void addLabel(String text, GridBagConstraints gbc, int row) {
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = row;
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(TEXT_COLOR);
        add(label, gbc);
    }

    private JTextField createTextField(GridBagConstraints gbc) {
        JTextField textField = new JTextField(15);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        textField.setBackground(BACKGROUND_COLOR);
        textField.setForeground(TEXT_COLOR);
        textField.setCaretColor(TEXT_COLOR);
        textField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(TEXT_COLOR, 2),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        gbc.gridx = 1;
        add(textField, gbc);
        return textField;
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(TEXT_COLOR, 2));
        button.setPreferredSize(new Dimension(120, 35));

        // Hover Effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(TEXT_COLOR);
                button.setForeground(BUTTON_COLOR);
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(BUTTON_COLOR);
                button.setForeground(TEXT_COLOR);
            }
        });

        return button;
    }

    private void addFoodItem() {
        String itemId = itemIdField.getText().trim();
        String name = nameField.getText().trim();
        double price;

        try {
            price = Double.parseDouble(priceField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid price", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        FoodItem newItem = new FoodItem(itemId, name, price);
        vendor.addFoodItem(newItem);
        MainApplication.foodItemMap.put(itemId, newItem);
        StorageManager.saveMenus(MainApplication.userList);
        JOptionPane.showMessageDialog(this, "Food item added successfully");
        dispose();
    }
}