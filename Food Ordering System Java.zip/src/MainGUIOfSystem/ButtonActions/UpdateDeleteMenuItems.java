package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import Roles_and_Models.Vendor;
import Roles_and_Models.FoodItem;
import MainGUIOfSystem.MainApplication;
import MainServices.StorageManager;

public class UpdateDeleteMenuItems extends JDialog {
    private Vendor vendor;
    private JList<String> foodList;
    private DefaultListModel<String> listModel;
    private JButton updateButton, deleteButton;
    private MainApplication mainFrame;

    public UpdateDeleteMenuItems(MainApplication frame, Vendor vendor) {
        super(frame, "Manage Food Items", true);
        this.mainFrame = frame;
        this.vendor = vendor;
        setSize(450, 350);
        setLocationRelativeTo(frame);
        setLayout(new BorderLayout(10, 10));

        // Set background color to dark with purple tint
        getContentPane().setBackground(new Color(40, 20, 60));

        listModel = new DefaultListModel<>();
        for (FoodItem item : vendor.getMenu()) {
            listModel.addElement(item.toString());
        }

        foodList = new JList<>(listModel);
        foodList.setFont(new Font("Arial", Font.PLAIN, 14));
        foodList.setBackground(new Color(30, 30, 50)); // Dark background
        foodList.setForeground(Color.WHITE); // White text
        foodList.setSelectionBackground(new Color(128, 0, 128)); // Purple selection
        foodList.setSelectionForeground(Color.GREEN); // Green text for selected item
        add(new JScrollPane(foodList), BorderLayout.CENTER);

        // Creating a panel for buttons
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBackground(new Color(40, 20, 60)); // Match background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        updateButton = createStyledButton("Update", new Color(0, 153, 0)); // Green button
        deleteButton = createStyledButton("Delete", new Color(153, 0, 0)); // Dark red button

        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonPanel.add(updateButton, gbc);

        gbc.gridx = 1;
        buttonPanel.add(deleteButton, gbc);

        add(buttonPanel, BorderLayout.SOUTH);

        updateButton.addActionListener(e -> {
            int index = foodList.getSelectedIndex();
            if (index < 0 || index >= vendor.getMenu().size()) {
                JOptionPane.showMessageDialog(this, "Select an item to update", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            FoodItem item = vendor.getMenu().get(index);
            new UpdateMenuItem(mainFrame, vendor, item, index).setVisible(true);
            listModel.set(index, item.toString());
            StorageManager.saveMenus(MainApplication.userList);
        });

        deleteButton.addActionListener(e -> {
            int index = foodList.getSelectedIndex();
            if (index < 0 || index >= vendor.getMenu().size()) {
                JOptionPane.showMessageDialog(this, "Select an item to delete", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            vendor.getMenu().remove(index);
            listModel.remove(index);
            StorageManager.saveMenus(MainApplication.userList);
            JOptionPane.showMessageDialog(this, "Food item deleted");
        });
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setPreferredSize(new Dimension(120, 40));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        button.setOpaque(true);
        button.setContentAreaFilled(true);

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });
        return button;
    }
}
