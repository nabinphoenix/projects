package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import Roles_and_Models.Order;
import Roles_and_Models.OrderStatus;
import Roles_and_Models.Vendor;
import MainGUIOfSystem.MainApplication;
import MainServices.StorageManager;

public class ProcessOrderDialog extends JDialog {
    private Vendor vendor;
    private JList<String> orderListDisplay;
    private DefaultListModel<String> listModel;
    private JButton processButton;
    private MainApplication mainFrame;
    private List<Order> pendingOrders;

    public ProcessOrderDialog(MainApplication frame, Vendor vendor) {
        super(frame, "Process Pending Orders", true);
        this.mainFrame = frame;
        this.vendor = vendor;
        setSize(500, 350);
        setLocationRelativeTo(frame);
        setLayout(new BorderLayout(10, 10));

        // Set background color to dark theme
        getContentPane().setBackground(new Color(30, 30, 30));

        listModel = new DefaultListModel<>();
        pendingOrders = new ArrayList<>();

        // Add only pending orders to the list
        for (Order o : vendor.getOrders()) {
            if (o.getStatus() == OrderStatus.PENDING) {
                pendingOrders.add(o);
                listModel.addElement("Order ID: " + o.getOrderId() +
                        " | Customer: " + o.getCustomer().getName() +
                        " | Status: " + o.getStatus());
            }
        }

        orderListDisplay = new JList<>(listModel);
        orderListDisplay.setFont(new Font("Arial", Font.PLAIN, 14));
        orderListDisplay.setBackground(new Color(40, 40, 60)); // Dark Purple
        orderListDisplay.setForeground(new Color(255, 255, 255)); // White Text
        orderListDisplay.setSelectionBackground(new Color(102, 0, 102)); // Deep Purple
        orderListDisplay.setSelectionForeground(new Color(0, 255, 127)); // Green Text for Selected Item

        add(new JScrollPane(orderListDisplay), BorderLayout.CENTER);

        // Create and style the process button
        processButton = createStyledButton("Process Selected Order");
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(30, 30, 30));
        buttonPanel.add(processButton);
        add(buttonPanel, BorderLayout.SOUTH);

        processButton.addActionListener(e -> {
            int index = orderListDisplay.getSelectedIndex();
            if (index < 0 || index >= pendingOrders.size()) {
                JOptionPane.showMessageDialog(ProcessOrderDialog.this,
                        "Select an order to process", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            Order selectedOrder = pendingOrders.get(index);
            int actualIndex = vendor.getOrders().indexOf(selectedOrder);
            new VendorProcessOrder(mainFrame, vendor, selectedOrder, actualIndex).setVisible(true);

            // Update UI after processing
            if (selectedOrder.getStatus() != OrderStatus.PENDING) {
                pendingOrders.remove(index);
                listModel.remove(index);
            } else {
                listModel.set(index, "Order ID: " + selectedOrder.getOrderId() +
                        " | Customer: " + selectedOrder.getCustomer().getName() +
                        " | Status: " + selectedOrder.getStatus());
            }
            StorageManager.saveOrders(MainApplication.orderList);
        });
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(new Color(128, 0, 128)); // Purple
        button.setForeground(new Color(255, 255, 255)); // White Text
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(250, 50));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(0, 255, 127), 2)); // Green Border
        button.setOpaque(true);
        button.setContentAreaFilled(true);

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(102, 0, 153)); // Darker Purple on Hover
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(128, 0, 128)); // Original Purple
            }
        });

        return button;
    }
}
