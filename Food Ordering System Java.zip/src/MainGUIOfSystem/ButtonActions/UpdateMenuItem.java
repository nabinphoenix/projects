package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import Roles_and_Models.Vendor;
import Roles_and_Models.FoodItem;
import MainGUIOfSystem.MainApplication;
import MainServices.StorageManager;

public class UpdateMenuItem extends JDialog {
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);

    private JTextField nameField, priceField;
    private JButton updateButton;
    private Vendor vendor;
    private FoodItem item;
    private int index;
    private MainApplication mainFrame;

    public UpdateMenuItem(MainApplication frame, Vendor vendor, FoodItem item, int index) {
        super(frame, "Update Food Item", true);
        this.mainFrame = frame;
        this.vendor = vendor;
        this.item = item;
        this.index = index;

        setSize(400, 200);
        setLocationRelativeTo(frame);
        setLayout(new GridLayout(3, 2, 5, 5));
        getContentPane().setBackground(BACKGROUND_COLOR);

        JLabel nameLabel = new JLabel("New Name:");
        nameLabel.setForeground(TEXT_COLOR);
        add(nameLabel);

        nameField = new JTextField(item.getName());
        add(nameField);

        JLabel priceLabel = new JLabel("New Price:");
        priceLabel.setForeground(TEXT_COLOR);
        add(priceLabel);

        priceField = new JTextField(String.valueOf(item.getPrice()));
        add(priceField);

        updateButton = new JButton("Update");
        updateButton.setBackground(BUTTON_COLOR);
        updateButton.setForeground(Color.WHITE);
        add(updateButton);

        updateButton.addActionListener(e -> {
            String newName = nameField.getText().trim();
            double newPrice;
            try {
                newPrice = Double.parseDouble(priceField.getText().trim());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(UpdateMenuItem.this, "Invalid price", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            item.setName(newName);
            item.setPrice(newPrice);
            StorageManager.saveMenus(MainApplication.userList);
            JOptionPane.showMessageDialog(UpdateMenuItem.this, "Food item updated");
            dispose();
        });
    }
}
