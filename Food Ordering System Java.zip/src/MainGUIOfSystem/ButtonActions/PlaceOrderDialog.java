package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import javax.swing.plaf.basic.BasicComboBoxRenderer;
import java.awt.*;
import java.util.ArrayList;

import Roles_and_Models.*;
import MainGUIOfSystem.MainApplication;
import MainServices.Payment;
import MainServices.Notification;
import MainServices.StorageManager;

public class PlaceOrderDialog extends JDialog {

    // Keep the overall dialog background dark if you prefer
    private static final Color BACKGROUND_COLOR   = new Color(9, 0, 7);

    // Green color for labels
    private static final Color TEXT_COLOR         = new Color(100, 255, 100);

    // Button colors
    private static final Color BUTTON_COLOR       = new Color(128, 0, 128);
    private static final Color BUTTON_HOVER_COLOR = new Color(160, 0, 160);

    // Make the dropdown and text fields white for better visibility
    private static final Color INPUT_BG_COLOR     = Color.WHITE;
    private static final Color INPUT_BORDER_COLOR = new Color(180, 180, 180); // Light gray border
    private static final Color INPUT_TEXT_COLOR   = Color.BLACK;              // Black text

    private JComboBox<String> vendorBox;
    private JTextField itemsField;
    private JComboBox<String> orderTypeBox;
    private JButton placeOrderButton;

    private Customer customer;
    private MainApplication mainFrame;

    public PlaceOrderDialog(MainApplication frame, Customer customer) {
        super(frame, "Place Order", true);
        this.mainFrame = frame;
        this.customer = customer;

        setSize(500, 350);
        setLocationRelativeTo(frame);
        setLayout(new GridBagLayout());
        setBackground(BACKGROUND_COLOR);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        // Create UI Components
        JLabel vendorLabel = createStyledLabel("Select Vendor:");
        vendorBox = createStyledComboBox(getVendorNames());

        JLabel itemsLabel = createStyledLabel("Enter Food Item IDs (comma separated):");
        itemsField = createStyledTextField();

        JLabel orderTypeLabel = createStyledLabel("Order Type:");
        orderTypeBox = createStyledComboBox(new String[]{"DINE_IN", "TAKEAWAY", "DELIVERY"});

        placeOrderButton = createStyledButton("Place Order");

        // Add Components
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(vendorLabel, gbc);
        gbc.gridx = 1;
        add(vendorBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        add(itemsLabel, gbc);
        gbc.gridx = 1;
        add(itemsField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        add(orderTypeLabel, gbc);
        gbc.gridx = 1;
        add(orderTypeBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        add(placeOrderButton, gbc);

        // Button Action
        placeOrderButton.addActionListener(e -> placeOrder());

        // Apply Dialog Styles
        getContentPane().setBackground(BACKGROUND_COLOR);
    }

    /**
     * Retrieves the names of all Vendors from MainApplication.userList
     */
    private String[] getVendorNames() {
        ArrayList<Vendor> vendors = new ArrayList<>();
        for (User u : MainApplication.userList) {
            if (u instanceof Vendor) {
                vendors.add((Vendor) u);
            }
        }
        return vendors.stream().map(Vendor::getName).toArray(String[]::new);
    }

    /**
     * Creates a green-colored label
     */
    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);           // Green
        label.setFont(new Font("Arial", Font.BOLD, 14));
        return label;
    }

    /**
     * Creates a styled combo box with a custom renderer for color-coded options
     */
    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(new Font("Arial", Font.BOLD, 14));
        comboBox.setBackground(INPUT_BG_COLOR);                               // White background
        comboBox.setForeground(INPUT_TEXT_COLOR);                             // Black text
        comboBox.setBorder(BorderFactory.createLineBorder(INPUT_BORDER_COLOR, 2));
        comboBox.setRenderer(new CustomComboBoxRenderer());
        return comboBox;
    }

    /**
     * Creates a styled text field with a white background and black text
     */
    private JTextField createStyledTextField() {
        JTextField textField = new JTextField(20);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        textField.setBackground(INPUT_BG_COLOR);                             // White
        textField.setForeground(INPUT_TEXT_COLOR);                           // Black
        textField.setCaretColor(INPUT_TEXT_COLOR);
        textField.setBorder(BorderFactory.createLineBorder(INPUT_BORDER_COLOR, 2));
        return textField;
    }

    /**
     * Creates a styled button with purple background and green text
     */
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setBorder(BorderFactory.createLineBorder(TEXT_COLOR, 2));
        button.setFocusPainted(false);
        button.setOpaque(true);

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(BUTTON_HOVER_COLOR);
                button.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(BUTTON_COLOR);
                button.setForeground(TEXT_COLOR);
            }
        });
        return button;
    }

    /**
     * Action method for placing an order
     */
    private void placeOrder() {
        int vendorIndex = vendorBox.getSelectedIndex();
        if (vendorIndex < 0) {
            JOptionPane.showMessageDialog(this, "Please select a vendor!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Vendor selectedVendor = null;
        int count = -1;
        for (User u : MainApplication.userList) {
            if (u instanceof Vendor) {
                count++;
                if (count == vendorIndex) {
                    selectedVendor = (Vendor) u;
                    break;
                }
            }
        }

        if (selectedVendor == null) {
            JOptionPane.showMessageDialog(this, "Invalid vendor selection", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String itemsText = itemsField.getText().trim();
        if (itemsText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter food item IDs!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String[] itemIds = itemsText.split(",");
        ArrayList<FoodItem> orderItems = new ArrayList<>();
        for (String id : itemIds) {
            id = id.trim();
            for (FoodItem item : selectedVendor.getMenu()) {
                if (item.getItemId().equalsIgnoreCase(id)) {
                    orderItems.add(item);
                }
            }
        }

        if (orderItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No valid food items found!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        OrderType orderType = OrderType.valueOf((String) orderTypeBox.getSelectedItem());
        String orderId = "ORD" + (MainApplication.orderList.size() + 1);
        Order newOrder = new Order(orderId, customer, selectedVendor, orderItems, OrderStatus.PENDING, orderType);

        // Delivery fee for delivery orders
        if (orderType == OrderType.DELIVERY) {
            newOrder.setDeliveryFee(5.0);
        }

        double totalAmount = newOrder.getTotalAmount();
        if (Payment.processPayment(customer, totalAmount)) {
            MainApplication.orderList.add(newOrder);
            customer.addOrderHistory(newOrder);
            selectedVendor.addOrder(newOrder);
            StorageManager.saveOrders(MainApplication.orderList);
            StorageManager.saveUsers(MainApplication.userList);
            Notification.sendNotification(customer, "Order " + orderId + " placed successfully.");
            JOptionPane.showMessageDialog(this, "Order placed successfully!\nOrder ID: " + orderId);

            if (orderType == OrderType.DELIVERY) {
                DeliveryTask dt = findDeliveryTask(newOrder);
                if (dt == null) {
                    String taskId = "TASK" + (MainApplication.deliveryTaskList.size() + 1);
                    dt = new DeliveryTask(taskId, newOrder, null, "Pending");
                    MainApplication.deliveryTaskList.add(dt);
                }
            }
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Payment failed!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Finds an existing DeliveryTask for the new order, or returns null if none
     */
    private DeliveryTask findDeliveryTask(Order newOrder) {
        for (DeliveryTask task : MainApplication.deliveryTaskList) {
            if (task.getOrder().getOrderId().equals(newOrder.getOrderId())) {
                return task; // Return the existing task if found
            }
        }
        return null; // Return null if no matching task exists
    }

    /**
     * Custom renderer to color-code each option in the combo box
     */
    private class CustomComboBoxRenderer extends BasicComboBoxRenderer {
        @Override
        public Component getListCellRendererComponent(
                JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {

            Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            // For the selected item or hovered item, give a highlight color
            if (isSelected) {
                c.setBackground(new Color(220, 220, 220)); // Light gray highlight
            } else {
                c.setBackground(INPUT_BG_COLOR);           // White background for unselected
            }

            // Color-code the text based on index
            if (index == 0) {
                c.setForeground(Color.RED);
            } else if (index == 1) {
                c.setForeground(Color.BLUE);
            } else if (index == 2) {
                c.setForeground(Color.ORANGE);
            } else {
                c.setForeground(INPUT_TEXT_COLOR); // Default to black
            }

            return c;
        }
    }
}
