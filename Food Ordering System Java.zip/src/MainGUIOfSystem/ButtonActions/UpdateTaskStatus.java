package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Roles_and_Models.DeliveryTask;
import Roles_and_Models.DeliveryRunner;
import MainGUIOfSystem.MainApplication;

public class UpdateTaskStatus extends JDialog {
    private JComboBox<String> taskBox;
    private JComboBox<String> statusBox;
    private JButton updateButton;
    private JButton cancelButton;
    private java.util.List<DeliveryTask> availableTasks;
    private DeliveryRunner runner;
    private MainApplication mainFrame;

    // Colors and styling constants
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR = new Color(128, 0, 128);
    // Dialog button dimensions
    private static final int DIALOG_BUTTON_WIDTH = 100;
    private static final int DIALOG_BUTTON_HEIGHT = 50;
    private static final int DIALOG_BUTTON_CORNER_RADIUS = 25;

    public UpdateTaskStatus(MainApplication frame, DeliveryRunner runner) {
        super(frame, "Update Task Status ", true);
        this.mainFrame = frame;
        this.runner = runner;
        initComponents();
    }

    private void initComponents() {
        getContentPane().setBackground(BACKGROUND_COLOR);
        setLayout(new BorderLayout(10, 10));
        setSize(450, 300);
        setLocationRelativeTo(mainFrame);

        // Content Panel with GridBagLayout for inputs
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(BACKGROUND_COLOR);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label and ComboBox for Task selection
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel taskLabel = new JLabel("Select Task:");
        taskLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        taskLabel.setForeground(TEXT_COLOR);
        contentPanel.add(taskLabel, gbc);

        // Build availableTasks list
        availableTasks = new java.util.ArrayList<>();
        for (DeliveryTask t : MainApplication.deliveryTaskList) {
            if ((t.getRunner() == null && t.getStatus().equalsIgnoreCase("Pending")) ||
                    (t.getRunner() != null && t.getRunner().equals(runner))) {
                availableTasks.add(t);
            }
        }
        String[] taskIds = new String[availableTasks.size()];
        for (int i = 0; i < availableTasks.size(); i++) {
            DeliveryTask t = availableTasks.get(i);
            taskIds[i] = t.getTaskId() + " (Order: " + t.getOrder().getOrderId() + ") - " + t.getStatus();
        }
        taskBox = new JComboBox<>(taskIds);
        taskBox.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 0;
        contentPanel.add(taskBox, gbc);

        // Label and ComboBox for New Status
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel statusLabel = new JLabel("New Status:");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        statusLabel.setForeground(TEXT_COLOR);
        contentPanel.add(statusLabel, gbc);

        String[] statuses = {"Accepted", "Declined", "Completed"};
        statusBox = new JComboBox<>(statuses);
        statusBox.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        contentPanel.add(statusBox, gbc);

        add(contentPanel, BorderLayout.CENTER);

        // Button Panel using custom dialog buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BACKGROUND_COLOR);
        updateButton = createDialogStyledButton("Update");
        // Increase the size of the update button
        updateButton.setPreferredSize(new Dimension(110, 50));
        cancelButton = createDialogStyledButton("Cancel");

        updateButton.addActionListener(e -> {
            int index = taskBox.getSelectedIndex();
            if(index < 0 || index >= availableTasks.size()){
                showCustomErrorMessage("Select a valid task");
                return;
            }
            DeliveryTask task = availableTasks.get(index);
            String newStatus = (String) statusBox.getSelectedItem();
            if(task.getRunner() == null && newStatus.equalsIgnoreCase("Accepted")) {
                task.setRunner(runner);
                task.setStatus("Accepted");
                showCustomMessage("Task accepted. You are now assigned to this task.");
            } else if(task.getRunner() != null && task.getRunner().equals(runner)) {
                task.setStatus(newStatus);
                if(newStatus.equalsIgnoreCase("Completed")) {
                    task.getOrder().setStatus(Roles_and_Models.OrderStatus.DELIVERED);
                    runner.addTaskToHistory(task);
                    showCustomMessage("Task completed. Order marked as delivered.");
                } else if(newStatus.equalsIgnoreCase("Declined")) {
                    task.setRunner(null);
                    task.setStatus("Pending");
                    showCustomMessage("Task declined. It is now available for other runners.");
                } else {
                    showCustomMessage("Task status updated to " + newStatus);
                }
            } else {
                showCustomErrorMessage("Invalid operation.");
                return;
            }
            dispose();
        });
        cancelButton.addActionListener(e -> dispose());

        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Helper: Create a custom dialog button with increased size.
    private JButton createDialogStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getModel().isPressed() ? getBackground().darker() : getBackground();
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), DIALOG_BUTTON_CORNER_RADIUS, DIALOG_BUTTON_CORNER_RADIUS);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setPreferredSize(new Dimension(DIALOG_BUTTON_WIDTH, DIALOG_BUTTON_HEIGHT));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);
        button.setBorder(new RoundedBorder(DIALOG_BUTTON_CORNER_RADIUS));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_COLOR.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    // Helper: Show custom error message in a dialog.
    private void showCustomErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Helper: Show custom informational message in a dialog.
    private void showCustomMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }

    // Custom Border class for rounded borders.
    private static class RoundedBorder implements javax.swing.border.Border {
        private int radius;
        RoundedBorder(int radius) {
            this.radius = radius;
        }
        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 1, radius + 1, radius + 1, radius + 1);
        }
        @Override
        public boolean isBorderOpaque() {
            return true;
        }
        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT_COLOR);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }
}
