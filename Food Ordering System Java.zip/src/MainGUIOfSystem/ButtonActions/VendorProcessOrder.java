package MainGUIOfSystem.ButtonActions;

import javax.swing.*;
import java.awt.*;
import Roles_and_Models.Order;
import Roles_and_Models.OrderStatus;
import Roles_and_Models.Vendor;
import MainServices.Notification;
import MainGUIOfSystem.MainApplication;
import MainServices.StorageManager;

public class VendorProcessOrder extends JDialog {
    private Vendor vendor;
    private Order order;
    private int orderIndex;
    private JButton acceptButton, declineButton;
    private MainApplication mainFrame;

    public VendorProcessOrder(MainApplication frame, Vendor vendor, Order order, int orderIndex) {
        super(frame, "Process Order " + order.getOrderId(), true);
        this.mainFrame = frame;
        this.vendor = vendor;
        this.order = order;
        this.orderIndex = orderIndex;
        setSize(400,200);
        setLocationRelativeTo(frame);
        setLayout(new GridLayout(2,1,5,5));

        JPanel infoPanel = new JPanel();
        infoPanel.add(new JLabel("Order ID: " + order.getOrderId() + " | Customer: " + order.getCustomer().getName()));
        add(infoPanel);

        JPanel buttonPanel = new JPanel();
        acceptButton = new JButton("Accept Order");
        declineButton = new JButton("Decline Order");
        buttonPanel.add(acceptButton);
        buttonPanel.add(declineButton);
        add(buttonPanel);

        acceptButton.addActionListener(e -> {
            order.setStatus(OrderStatus.ACCEPTED);
            Notification.sendNotification(order.getCustomer(), "Your order " + order.getOrderId() + " has been accepted by " + vendor.getName());
            if(order.getOrderType() == Roles_and_Models.OrderType.DELIVERY) {
                Roles_and_Models.DeliveryTask dt = findDeliveryTask(order);
                if(dt == null) {
                    String taskId = "TASK" + (MainApplication.deliveryTaskList.size() + 1);
                    dt = new Roles_and_Models.DeliveryTask(taskId, order, null, "Pending");
                    MainApplication.deliveryTaskList.add(dt);
                } else {
                    dt.setStatus("Pending");
                    dt.setRunner(null);
                }
            }
            StorageManager.saveOrders(MainApplication.orderList);
            JOptionPane.showMessageDialog(VendorProcessOrder.this, "Order accepted");
            dispose();
        });

        declineButton.addActionListener(e -> {
            order.setStatus(OrderStatus.DECLINED);
            MainServices.Payment.refundPayment(order.getCustomer(), order.getTotalAmount());
            Notification.sendNotification(order.getCustomer(), "Your order " + order.getOrderId() + " has been declined by " + vendor.getName());
            StorageManager.saveOrders(MainApplication.orderList);
            JOptionPane.showMessageDialog(VendorProcessOrder.this, "Order declined and customer refunded");
            dispose();
        });
    }

    private Roles_and_Models.DeliveryTask findDeliveryTask(Order order) {
        for(Roles_and_Models.DeliveryTask dt : MainApplication.deliveryTaskList) {
            if(dt.getOrder().equals(order))
                return dt;
        }
        return null;
    }
}
