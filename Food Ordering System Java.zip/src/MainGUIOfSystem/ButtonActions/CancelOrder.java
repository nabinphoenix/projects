package MainGUIOfSystem.ButtonActions;

import MainGUIOfSystem.MainApplication;
import Roles_and_Models.Customer;
import Roles_and_Models.Order;
import Roles_and_Models.OrderStatus;
import MainServices.Notification;
import MainServices.Payment;
import MainServices.StorageManager;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class CancelOrder extends JDialog {

    // ========== COLOR SCHEME (Same as AdminDashboard) ==========
    private static final Color BACKGROUND_COLOR = new Color(9, 0, 7);
    private static final Color TEXT_COLOR       = new Color(100, 255, 100);
    private static final Color BUTTON_COLOR     = new Color(128, 0, 128);

    // Corner radius for rounded edges
    private static final int CORNER_RADIUS = 20;

    private JComboBox<String> orderBox;
    private JButton cancelButton;

    public CancelOrder(MainApplication frame, Customer customer) {
        super(frame, "Cancel Order", true);

        // Basic dialog setup
        setSize(400, 250);
        setLocationRelativeTo(frame);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(BACKGROUND_COLOR);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);  // Padding for better spacing
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 1) Label for "Select Pending Order" (green text)
        JLabel promptLabel = createStyledLabel("Select Pending Order:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(promptLabel, gbc);

        // 2) Find all PENDING orders for this customer
        ArrayList<Order> pendingOrders = new ArrayList<>();
        for (Order o : customer.getOrderHistory()) {
            if (o.getStatus() == OrderStatus.PENDING) {
                pendingOrders.add(o);
            }
        }

        // If no pending orders, show a message and close
        if (pendingOrders.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No pending orders to cancel.", "Error", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // 3) Build an array of pending order IDs for the combo box
        String[] orderIds = new String[pendingOrders.size()];
        for (int i = 0; i < pendingOrders.size(); i++) {
            orderIds[i] = pendingOrders.get(i).getOrderId();
        }

        // 4) Styled combo box
        orderBox = createStyledComboBox(orderIds);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(orderBox, gbc);

        // 5) Styled "Cancel Order" button
        cancelButton = createStyledButton("Cancel Order");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(cancelButton, gbc);

        // 6) Cancel button logic
        cancelButton.addActionListener(e -> {
            int index = orderBox.getSelectedIndex();
            if (index < 0 || index >= pendingOrders.size()) {
                JOptionPane.showMessageDialog(
                        CancelOrder.this, "Invalid selection", "Error", JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            Order orderToCancel = pendingOrders.get(index);
            orderToCancel.setStatus(OrderStatus.CANCELLED);

            // Refund the full amount
            Payment.refundPayment(customer, orderToCancel.getTotalAmount());
            Notification.sendNotification(customer,
                    "Order " + orderToCancel.getOrderId() + " cancelled and refunded.");

            // Save updated data
            StorageManager.saveOrders(MainApplication.orderList);
            StorageManager.saveUsers(MainApplication.userList);

            JOptionPane.showMessageDialog(CancelOrder.this, "Order cancelled.");
            dispose();
        });
    }

    // ========== STYLING HELPERS ==========

    /** Create a label with green text (TEXT_COLOR) */
    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(TEXT_COLOR);
        label.setFont(new Font("Arial", Font.BOLD, 16));
        return label;
    }

    /** Create a combo box with dark background, green text, and a round border */
    private JComboBox<String> createStyledComboBox(String[] items) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        comboBox.setBackground(BACKGROUND_COLOR.darker());  // Slightly lighter/darker if desired
        comboBox.setForeground(TEXT_COLOR);
        comboBox.setBorder(BorderFactory.createLineBorder(TEXT_COLOR, 2));

        // Optional: Larger size for better UI
        comboBox.setPreferredSize(new Dimension(250, 30));
        return comboBox;
    }

    /**
     * Create a styled button that matches the AdminDashboard look:
     * - Purple background
     * - Green text
     * - Rounded corners
     * - Hover effect
     */
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // Fill rounded rectangle background
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), CORNER_RADIUS, CORNER_RADIUS);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        button.setFont(new Font("Arial", Font.BOLD, 16));
        button.setBackground(BUTTON_COLOR);
        button.setForeground(TEXT_COLOR);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setOpaque(false);

        // Use a rounded border
        button.setBorder(new RoundedBorder(CORNER_RADIUS));

        // Hover effect: brighten background
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_COLOR.brighter());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_COLOR);
            }
        });
        return button;
    }

    /**
     * A simple custom border for rounded edges.
     */
    private static class RoundedBorder implements Border {
        private final int radius;
        public RoundedBorder(int radius) {
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(TEXT_COLOR);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 1, radius + 1, radius + 1, radius + 1);
        }

        @Override
        public boolean isBorderOpaque() {
            return false;
        }
    }
}
