from validations import *


def check_empty_file():
    try:
        with open('personnel_details.txt', 'r') as fp:
            check = len(fp.readlines())
            if check == 0:
                print('No personnel exists')
                return True
            return False
    except FileNotFoundError:
        print('Personnel file not found.')
        return True

def personnel_login():
    if check_empty_file():
        return False
    try:
        with open('personnel_details.txt', "r") as fp:
            content = fp.readlines()
            tries = 0
            while tries < 3:
                username = input('Enter username:')
                password = input('Enter password:')
                iD = input('Enter your ID:')
                login_success = False
                for line in content:
                    details = line.split()
                    if len(details) == 7:  # Ensure the line has all the required details
                        USERNAME = details[-3]
                        PASSWORD = details[-2]
                        ID = details[-1]
                        if username == USERNAME and password == PASSWORD and iD == ID:
                            print('Login successful!')
                            return True
                if not login_success:
                    print('Invalid username or password!, Try again')
                tries += 1
            print('Login failed')
            return False
    except FileNotFoundError:
        print('Personnel file not found.')
        return False




def change_personnel_details():
    try:
        with open('personnel_details.txt', "r") as fp:
            content = fp.read()
            details = content.split()
            
            while True:
                USERNAME = input("Enter your new username: ")
                if is_valid_username(USERNAME):
                    break
                print("Invalid username. Please try again.")
            
            while True:
                PASSWORD = input("Enter your new password: ")
                if is_valid_password(PASSWORD):
                    break
                print("Invalid password. Please try again.")
                
        details[-1] = PASSWORD
        details[-2] = USERNAME
        with open('personnel_details.txt', 'w') as fp:
            fp.write(' '.join(details))
        print('Personnel details updated successfully.')
    except FileNotFoundError:
        print('Personnel file not found.')

def create_papers():
    mcq = {}
    subjective = {}
    while True:
        choosingSetChoice = int(input('Which question set do you want to create?\n1.SET1\n2.SET2\n3.Exit\nEnter your choice with respective number:'))
        if choosingSetChoice == 1:
            file_name = "SET1.txt"
            break
        elif choosingSetChoice == 2:
            file_name = "SET2.txt"
            break
        elif choosingSetChoice == 3: 
            return
            
        else:
            print('Invalid choice, Enter again.')

    try:
        with open('objective_questions.txt') as fp:
            print("Choose from these MCQs:")
            for j, i in enumerate(fp):
                content = i.split(':')
                question = content[2]
                mainOptions = content[3].split('#')
                mainOptions_format = f'\na.{mainOptions[0]}  b.{mainOptions[1]}  c.{mainOptions[2]}  d.{mainOptions[3]}\n'
                mcq[j + 1] = f'{question}:{mainOptions_format}'
                print(f'{j + 1}.{question}\n\ta.{mainOptions[0]}  b.{mainOptions[1]}  c.{mainOptions[2]}  d.{mainOptions[3]}')
    except FileNotFoundError:
        print('Objective questions file not found.')
        return

    try:
        with open('subjective_questions.txt') as fp:
            print("Choose from these subjective questions:")
            for j, i in enumerate(fp):
                content = i.split(":")
                question = content[2]
                print(f'{j + 1}. {question}')
                subjective[j + 1] = f'{question}'
    except FileNotFoundError:
        print('Subjective questions file not found.')
        return

    while True:
        while True:
            number_of_MCQs_Questions = input('Enter the number of MCQ questions:')
            if is_valid_number(number_of_MCQs_Questions):
                no_of_mcq = int(number_of_MCQs_Questions)
                break
            else:
                print("Invalid input. Please enter a valid number without any text or symbols.")
        
        while True:
            number_of_subjectiveQuestions = input('Enter the number of subjective questions:')
            if is_valid_number(number_of_subjectiveQuestions):
                no_of_subjectives = int(number_of_subjectiveQuestions)
                break
            else:
                print("Invalid input. Please enter a valid number without any text or symbols.")
        
        if no_of_mcq >= 5 and no_of_subjectives >= 3:
            break
        print("There should be at least 5 MCQs and 3 subjective questions.")

    try:
        with open(file_name, 'w') as fp:
            fp.write('\n' + '*'*15 + ' Section "A" ' + '*'*15 + '\n')

            for i in range(no_of_mcq):
                while True:
                    n = int(input(f'Enter MCQ no {i + 1}:'))
                    if n in mcq:
                        fp.write(f'{i + 1}.{mcq[n]}\n')
                        break
                    else:
                        print("Invalid MCQ number. Please try again.")
            fp.write('\n' + '*'*15 + ' Section "B" ' + '*'*15 + '\n')

            for i in range(no_of_subjectives):
                while True:
                    n = int(input(f'Enter Subjective question no {i + 1}:'))
                    if n in subjective:
                        fp.write(f'{i + 1}.{subjective[n]}\n')
                        break
                    else:
                        print("Invalid subjective question number. Please try again.")
        print(f'Paper {file_name} created successfully.')
    except IOError:
        print('An error occurred while writing to the file.')

def view_papers():
    while True:
        choosingSetChoice = int(input('Which question set do you want to view?\n1.SET1\n2.SET2\nEnter your choice:'))
        if choosingSetChoice == 1:
            file_name = "SET1.txt"
            break
        elif choosingSetChoice == 2:
            file_name = "SET2.txt"
            break
        print('Invalid choice, Enter again.')
    
    try:
        with open(file_name, 'r') as fp:
            check = len(fp.readlines())
            if check == 0:
                print('Question paper does not exist')
                return
            fp.seek(0)
            content = fp.read()
            print(content)
    except FileNotFoundError:
        print('Question paper file not found.')

def delete_papers():
    try:
        with open('SET1.txt', 'w') as fp:
            pass
        with open('SET2.txt', 'w') as fp:
            pass
        print('All papers deleted successfully.')
    except IOError:
        print('An error occurred while deleting the files.')
