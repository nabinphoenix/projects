from extras import *
from validations import *

def lecturer_login():
    try:
        with open('lecturer_details.txt', "r") as fp:
            changed_USERNAME_pass = {}
            for i in fp:
                full_detail_of_lecturer = i.split()
                changed_USERNAME = full_detail_of_lecturer[-2]
                changed_PASSWORD = full_detail_of_lecturer[-1]
                changed_USERNAME_pass[changed_USERNAME] = changed_PASSWORD
            login_attempts = 0
            while login_attempts < 3:
                userName = input('Enter your Username:')
                passWord = input('Enter your Password:')
                if userName in changed_USERNAME_pass and passWord == changed_USERNAME_pass[userName]:
                    print('Login Successful')
                    return True
                print('Invalid Username or Password! Try again')
                login_attempts += 1
            print('Login failed')
            return False
    except FileNotFoundError:
        print('Lecturer details file not found.')
        return False


def is_valid_username(username):
    # Implement your username validation logic here
    return len(username) > 0  # Example validation, adjust as needed

def is_valid_password(password):
    # Implement your password validation logic here
    return len(password) > 5  # Example validation, adjust as needed

def change_lecturer_details():
    try:
        with open('lecturer_details.txt', "r") as fp:
            main_contents = fp.readlines()
        
        # Ask for Old ID, Username, and Password
        while True:
            old_id = input("Enter your Old ID: ")
            old_username = input("Enter your Old Username: ")
            old_password = input("Enter your Old Password: ")

            # Verify the old details
            for line in main_contents:
                details = line.split()
                if details[-3] == old_id and details[-2] == old_username and details[-1] == old_password:
                    break
            else:
                print("Old ID, Username, or Password is incorrect. Please try again.")
                continue
            break

        updated = False
        new_lines = []
        for line in main_contents:
            details = line.split()
            if details[-3] == old_id and details[-2] == old_username and details[-1] == old_password:
                while True:
                    changed_username = input("Enter your new Username: ")
                    if is_valid_username(changed_username):
                        break
                    print("Invalid Username. Please try again.")
                
                while True:
                    changed_password = input("Enter your new Password: ")
                    if is_valid_password(changed_password):
                        break
                    print("Invalid Password. Please try again.")
                
                details[-2] = changed_username
                details[-1] = changed_password
                updated = True
            
            new_lines.append(' '.join(details))
        
        if updated:
            with open('lecturer_details.txt', 'w') as fp:
                fp.write('\n'.join(new_lines))
            print('Lecturer details updated successfully.')
        else:
            print('Details not found for the provided ID, Username, and Password.')
    
    except FileNotFoundError:
        print('Lecturer details file not found.')



def view_question_answers():
    def subjective():
        try:
            with open("subjective_questions.txt", "r") as fp:
                lines = fp.readlines()
                while True:
                    subject = input('\n\nInput the subject to view questions of:')
                    topic = input('Enter the topic to view questions of:')
                    boolean_value = False
                    for i in lines:
                        if subject in i and topic in i:
                            boolean_value = True
                            break
                    if boolean_value:
                        break
                    print('Questions not added, Try again')
                print('Questions are:')
                fp.seek(0)
                for i in lines:
                    subject_and_topics = i.split(':')
                    if subject_and_topics[0] == subject and subject_and_topics[1] == topic:
                        print(f'QN.{subject_and_topics[2]}')
        except FileNotFoundError:
            print('Subjective questions file not found.')

    def objective():
        try:
            with open("objective_questions.txt", "r") as fp:
                lines = fp.readlines()
                while True:
                    subject = input('\n\nInput the subject to view questions of:')
                    topic = input('Enter the topic to view questions of:')
                    boolean_value = False
                    for i in lines:
                        if subject in i and topic in i:
                            boolean_value = True
                            break
                    if boolean_value:
                        break
                    print('Questions not added, Try again')
                print('Questions and answers are:')
                fp.seek(0)
                for i in lines:
                    subject_and_topics = i.split(':')
                    option_string = subject_and_topics[3]
                    options = option_string.split('#')
                    if subject_and_topics[0] == subject and subject_and_topics[1] == topic:
                        print(f'QN.{subject_and_topics[2]}')
                        print(f'  a.{options[0]} b.{options[1]} c.{options[2]} d.{options[3]}')
                        print(f'  ans:{subject_and_topics[-1]}')
        except FileNotFoundError:
            print('Objective questions file not found.')

    while True:
        print('~'*15, 'QUESTIONS VIEW', '~'*15)
        choice = int(input('Do you want to view MCQ or subjective questions?\n1. Sub\n2. MCQ\nEnter your choice:'))
        if choice == 1:
            subjective()
            break
        elif choice == 2:
            objective()
            break
        else:
            print('Invalid choice, Try again')

def delete_questions():
    try:
        with open("subjective_questions.txt", "r") as fp:
            main_contents= fp.read()
            content_list = main_contents.split('\n')
            
        while True:
            subject = input('\n\nInput the subject to delete questions of:')
            topic = input('Enter the topic to delete questions for:')
            boolean_value = False
            for i in content_list:
                if subject in i and topic in i:
                    boolean_value = True
                    break
            if boolean_value:
                break
            print("Questions don't exist, Try again")

        with open('subjective_questions.txt', 'w') as qp:
            for i in content_list:
                subject_and_topics = i.split(':')
                if subject_and_topics[0] == subject and subject_and_topics[1] == topic:
                    continue
                qp.write(i + '\n')
        print('Questions deleted successfully.')
    except FileNotFoundError:
        print('Subjective questions file not found.')

def add_questions():
    def add_subjective():
        try:
            with open('subjective_questions.txt', 'a') as f:
                n = int(input('Enter the number of subjective questions that you want to enter:'))
                for i in range(n):
                    question = input(f'Enter question no {i + 1}:')
                    f.write(f'{subject}:{topic}:{question}\n')
            print('Questions added successfully.')
        except IOError:
            print('An error occurred while writing to the file.')

    def add_mcq():
        try:
            with open('objective_questions.txt', 'a') as f:
                numbers = int(input('Enter the number of MCQs that you want to enter:'))
                for x in range(numbers):
                    main_options = ['','a','b','c','d']
                    question = input(f'Enter question number {x + 1}:')
                    options = []
                    for y in range(4):
                        options.append(input(f"Enter option number {y + 1}:"))
                    ans = input(f'Enter the correct option:')
                    answer = main_options[int(ans)]
                    f.write(f'{subject}:{topic}:{question}:{"#".join(options)}:{answer}\n')
            print('Questions added successfully.')
        except IOError:
            print('An error occurred while writing to the file.')

    try:
        content_list = view_course()
        if content_list == True:
            return
        while True:
            subject = input('\n\nInput the subject to add questions for:')
            topic = input('Enter the topic to add questions for:')
            boolean_value = False
            for main_contents in content_list:
                if subject in main_contents and topic in main_contents:
                    boolean_value = True
                    break
            if boolean_value:
                break
            print('Invalid Subjects or Topics, Do it again.')

        while True:
            options = int(input('Do you want to add MCQs or Subjective Questions?\n1. Sub\n2. MCQ\nEnter number respective options:'))
            if options == 1:
                add_subjective()
                break
            elif options == 2:
                add_mcq()
                break
            else:
                print('Invalid input, Try again')
    except FileNotFoundError:
        print('Course file not found.')

def modify_question_answers():
    print('Choose the options below:')
    print('1. Add questions and answers:')
    print('2. Delete questions and answers:')
    print('3. Exit:')
    num = input('Enter numbers to perform respective tasks:')
    if num == '1':
        add_questions()
    elif num == '2':
        delete_questions()
    elif num == '3':
        return
    else:
        print("Invalid choice.")
