from admin import *
from lecturer import *
from personnel import *


def academic_admin():
    if not admin_login():
        return False
    
    while True:
        print('~' * 20, 'WELCOME TO','~' * 20)
        print('                  ADMIN INTERFACE')
        print('1.Modify and Update Lecturers')
        print('2.Modify and Update Personnels') 
        print('3.Modify and Update Courses')
        print('4.Exit the Admin Interface and go to main menu')
        print('~' * 20, 'THANK YOU','~' * 20)

        while True:
            try:
                n = int(input('\nEnter a number to do the corresponding tasks:'))
                break
            except ValueError:
                print('Invalid input. Please enter a number.')
                continue
            

        if n == 1:
            manage_lecturer()
        elif n == 2:
            manage_personnel()
        elif n == 3:
            manage_course()
        elif n == 4:
            print('Exiting admin interface...')
            break
        else:
            print('Invalid number. Please enter 1, 2, 3 or 4.')





def registered_lecturer():
    if not lecturer_login():
        return False
    while True:
        print('~' * 20, 'WELCOME TO','~' * 20)
        print('                LECTURER INTERFACE')
        print('1. Change Username and Password')
        print('2. View questions and answers')
        print('3. Modify and Update questions and answers')
        print('4. Exit the Lecturer Interface and go to main menu')
        print('~' * 20, 'THANK YOU','~' * 20)

        while True:
            try:
                n = int(input("\nEnter a number to do the corresponding tasks:"))
                break
            except ValueError:
                print('Invalid input. Please enter a number.')
                continue
            

        if n == 1:
            change_lecturer_details()
        elif n == 2:
            view_question_answers()
        elif n == 3:
            modify_question_answers()
        elif n == 4:
            break
        else:
            print('Invalid number')


def personnel():
    if not personnel_login():
        return False
    
    while True:
        print('~' * 20, 'WELCOME TO','~' * 20)
        print('                PERSONNEL INTERFACE')
        print('1. Change username and password')
        print('2. View sets of exam papers')
        print('3. Create sets of exam papers')
        print('4. Delete exam papers')
        print('5. Exit')
        print('~' * 20, 'THANK YOU','~' * 20)

        while True:
            try:
                n = int(input('\nEnter a number to do the corresponding tasks:'))
                break
            except ValueError:
                print('Invalid input. Please enter a number.')
                continue
            


        if n == 1:
            change_personnel_details()
        elif n == 2:
            view_papers()
        elif n == 3:
            create_papers()
            print('Paper created successfully.')
        elif n == 4:
            delete_papers()
        elif n == 5:
            break
        else:
            print('Invalid number')



def main_interface(): 
    n = 1
    while n != 4:

        print('~' * 20, 'WELCOME TO','~' * 20)
        print('           TEST QUESTION MANAGEMENT SYSTEM')
        print('1. Academic Admin')
        print('2. Registered lecturer')
        print('3. Exam unit personnel')
        print('4. Exit the Test Question Management System')
        print('~' * 20, 'THANK YOU','~' * 20)

        while True:
            try:
                n = int(input('\nEnter a number to do the corresponding tasks:'))
                break
            except ValueError:
                print('Invalid input. Please enter a number.')
                continue

        if n == 1:
            academic_admin()
        elif n == 2:
            registered_lecturer()
        elif n == 3:
            personnel()
        elif n == 4:
            print('Thank you for using Test Question Management System')
        else:
            print('Invalid number, Try again')


main_interface()
