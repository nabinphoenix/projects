def is_valid_number(input_str):
    # Check if the input string is a digit and does not contain any other characters
    return input_str.isdigit()

def is_valid_name(name):
    letter_count = 0
    for char in name:
        if char.isalpha():
            letter_count += 1
        else:
            return False
    return letter_count >= 3

def is_valid_address(address):
    has_number = False
    has_letter = False
    has_space = False
    letter_count = 0
    
    for char in address:
        if char.isdigit():
            has_number = True
        if char.isalpha():
            has_letter = True
            letter_count += 1
        if char.isspace():
            has_space = True
            
    return has_number and has_letter and not has_space and letter_count >=3

def is_valid_contact_number(contact_number):
    if len(contact_number) == 10 and contact_number.isdigit():
        return True
    return False

def is_valid_username(username):
    digit_count = 0
    has_letter = False
    
    for char in username:
        if char.isdigit():
            digit_count += 1
        if char.isalpha():
            has_letter = True
        if char.isspace():
            return False
    
    return digit_count >= 2 and has_letter

def is_valid_password(password):
    if len(password) < 4 or len(password) > 16:
        return False
    if not any(char.islower() for char in password):
        return False
    if not any(char.isupper() for char in password):
        return False
    if not any(char.isdigit() for char in password):
        return False
    if not any(char in '!@#$%^&*()_+-=[]{}|;:,.<>?/' for char in password):
        return False
    return True

def is_valid_date_of_birth(date_of_birth):
    # Check the format of the date_of_birth
    if len(date_of_birth) != 10 or date_of_birth[4] != '-' or date_of_birth[7] != '-':
        return False
    
    year = date_of_birth[:4]
    month = date_of_birth[5:7]
    day = date_of_birth[8:]

    # Validate if year, month, and day are digits
    if not (year.isdigit() and month.isdigit() and day.isdigit()):
        return False
    
    year = int(year)
    month = int(month)
    day = int(day)

    # Check year range
    if not (1924 <= year <= 2007):
        return False
    
    # Check month range
    if not (1 <= month <= 12):
        return False

    # Check day range for each month
    if month in [4, 6, 9, 11]:
        if not (1 <= day <= 30):
            return False
    elif month == 2:
        if not (1 <= day <= 28):  # Simplified: No leap year handling
            return False
    else:
        if not (1 <= day <= 31):
            return False
    
    return True

def calculate_age(date_of_birth, current_year=2024):
    year = int(date_of_birth[:4])
    return current_year - year

def is_valid_citizenship_number(citizenship_number):
    # Check the format of the citizenship_number
    if len(citizenship_number) != 13:
        return False
    
    # Check for correct dashes positions
    if citizenship_number[3] != '-' or citizenship_number[7] != '-':
        return False
    
    # Check if all characters except dashes are digits
    for i, char in enumerate(citizenship_number):
        if i in [3, 7]:  # Skip dashes
            continue
        if not char.isdigit():
            return False
    
    return True

def is_valid_id(id_number):
    # Check if the ID number is exactly 3 digits long
    if len(id_number) != 3:
        return False
    
    # Check if all characters are digits
    if id_number.isdigit():
        return True
    return False

def is_valid_email(email):
    # Check for exactly one '@' and at least one '.'
    if email.count('@') != 1:
        return False
    
    if '.' not in email:
        return False
    
    return True
