int calculate_age(char dob[20])   //This a function which calculate age through DOB
	{	
	int i,year=0;
	for(i=0;i<4;i++)			//iit takes the year from the DOB only first 4 character
	{
		year=year*10+(dob[i]-'0');  //converting character to integer
	}
	if((2024-year)>18)
	{
		return 0; 
	}
	else
	{
		printf("You are not eligible.");
		return 1;
	}
//	return 0;
	}


int VOTER_REGISTRATION(){
	char data[50];
	v v1;        				//declare a structure called voter
	int sno=0;
	FILE *fp;
	char ch;
	fp=fopen("voterlist.txt","r+");
	if(fp==NULL)
	{
		printf("unable to open the file.");
		return 0;
	}
sno =file_line_count(fp)-1;
	rewind(fp);
	if(fscanf(fp,"%s",&data)!=EOF)
	{
		fseek(fp, 0, SEEK_END);
		fprintf(fp,"\n");
		sno++;	
	}
	fclose(fp);
		printf("Enter your First name:");
		scanf("%s",&v1.firstname);
		printf("Enter your last name:");
		scanf("%s",&v1.lastname);
		printf("Enter your address:");
		scanf("%s",&v1.address);
		printf("Enter your DOB(yyyy/mm/dd):");
		scanf("%s",&v1.dob);
		printf("Create a password:");
		scanf("%s",&v1.password);
		if(calculate_age(v1.dob))
		{
			return 0;
		}
		
	fp=fopen("voterlist.txt","a");
		fprintf(fp,"%d\t",sno+1);
		
		fprintf(fp,"%s\t",v1.firstname);
		fprintf(fp,"%s\t",v1.lastname);
		fprintf(fp,"%s\t",v1.address);
		fprintf(fp,"%s\t",v1.dob);
		fprintf(fp,"%s\t",v1.password);
		fprintf(fp,"%d\t",v1.votecheck);
	printf("\n You are now registered and your voter SNO  is %d\n",sno+1);	
	
	fclose(fp);
	return 0;
}
int SEE_VOTER_INFORMATION(){
	FILE *fp;
	char pass[50];
	int i,sn,n;
	fp=fopen("voterlist.txt","r");
	n=file_line_count(fp);
	v v1[n];
	rewind(fp);
	for(i=0;i<n;i++){
		fscanf(fp,"%s",&v1[i].sno);
		fscanf(fp,"%s",&v1[i].firstname);
		fscanf(fp,"%s",&v1[i].lastname);
		fscanf(fp,"%s",&v1[i].dob);
		fscanf(fp,"%s",&v1[i].address);
		fscanf(fp,"%s",&v1[i].password);
		fscanf(fp,"%d",&v1[i].votecheck);
		
		
	}
	
	printf("Enter Your Voter Serial NUmber (SNO):");
	scanf("%d",&sn);
	sn-=1;
	if(sn<=n){
		
		printf("enter your password:");
		scanf("%s",&pass);
	//	if(strcmp(pass,v1[sn].password)!=0){
				if(strcmp(pass,v1[sn].password)){
			printf("wrong sno or password\n");
		
			return 0;
			
		}
		printf("\nYour details are:\n");
		printf("firstname:%s\n",v1[sn].firstname);
		printf("last_name:%s\n",v1[sn].lastname);
		printf("dob:%s\n",v1[sn].dob);
		printf("address:%s\n",v1[sn].address);
		printf("password:%s\n",v1[sn].password);
		
	}
	else {
		printf("Invalid SNO.\n");
	}
	return 0;

}

int MODIFY_VOTER_INFO(){
	FILE *fp;
	char pass[50];
	int i,sn,n;
	fp=fopen("voterlist.txt","r");
	n=file_line_count(fp);
	v v1[n];
	rewind(fp);
	for(i=0;i<n;i++){
		fscanf(fp,"%s",&v1[i].sno);
		fscanf(fp,"%s",&v1[i].firstname);
		fscanf(fp,"%s",&v1[i].lastname);
		fscanf(fp,"%s",&v1[i].dob);
		fscanf(fp,"%s",&v1[i].address);
		fscanf(fp,"%s",&v1[i].password);
		fscanf(fp,"%d",&v1[i].votecheck);		
	}
	printf("\nEnter your voter SNO:");
	scanf("%d",&sn);
	if(sn>n){
		printf("Not a valid voter SNO");
		return 0;
	}
	sn-=1;
	printf("Enter your password:");
	scanf("%s",&pass);
	if(strcmp(pass,v1[sn].password)){
		printf("Wrong password.");
		return 0;
	}
	printf("\nEnter your First Name:");
	scanf("%s",&v1[sn].firstname);
	printf("Enter your Last Name:");
	scanf("%s",&v1[sn].lastname);
	printf("Enter your DOB:");
	scanf("%s",&v1[sn].dob);
	printf("Enter your address:");
	scanf("%s",&v1[sn].address);
	printf("Create your password:");
	scanf("%s",&v1[sn].password);
	if(calculate_age(v1[sn].dob))
		{
			return 0;
		}
	fclose(fp);
	fp=fopen("voterlist.txt","w");
	for(i=0;i<n;i++)
	{
		fprintf(fp,"%d\t",i+1);
		fprintf(fp,"%s\t",v1[i].firstname);
		fprintf(fp,"%s\t",v1[i].lastname);
		fprintf(fp,"%s\t",v1[i].dob);
		fprintf(fp,"%s\t",v1[i].address);
		fprintf(fp,"%s\t",v1[i].password);
		fprintf(fp,"%d",v1[i].votecheck);
		if(i<n-1){
			fprintf(fp,"\n");
		}
	}
	printf("\nDetails changed successfully.");
	fclose(fp);
	return 0;	
}




int VOTE_CASTING(){
	FILE *fp;
	int i,number,SN;
	char no_candidate[20];
	char strongPassword[50];
	fp=fopen("voterlist.txt","r+");
	number=file_line_count(fp);
	v v1[number];
	
	rewind(fp);
	for(i=0;i<number;i++){
		fscanf(fp,"%s",&v1[i].sno);
		fscanf(fp,"%s",&v1[i].firstname);
		fscanf(fp,"%s",&v1[i].lastname);
		fscanf(fp,"%s",&v1[i].dob);
		fscanf(fp,"%s",&v1[i].address);
		fscanf(fp,"%s",&v1[i].password);
		fscanf(fp,"%d",&v1[i].votecheck);		
	}
	
	printf("\nEnter your voter SNO:");
	scanf("%d",&SN);
	if(SN>number){
		printf("Not a valid voter SNO");
		return 0;
	}
	SN-=1;
	if(v1[SN].votecheck==2){
		printf("\nSorry,You have already voted.\n");
		return 0;
	}
	v1[SN].votecheck+=1;
	rewind(fp);
	for(i=0;i<number;i++)
	{
		fprintf(fp,"%d\t",i+1);
		fprintf(fp,"%s\t",v1[i].firstname);
		fprintf(fp,"%s\t",v1[i].lastname);
		fprintf(fp,"%s\t",v1[i].dob);
		fprintf(fp,"%s\t",v1[i].address);
		fprintf(fp,"%s\t",v1[i].password);
		fprintf(fp,"%d",v1[i].votecheck);
		if(i<number-1){
			fprintf(fp,"\n");
		}
		
	}
	fclose(fp);
	fp=fopen("candidatelist.txt","r");
	int count=file_line_count(fp);
	rewind(fp);
	if(fscanf(fp,"%s",&no_candidate)==EOF){
		printf(" Could not vote because candidates are not registered");
		return 0;
	}
	c c1[count];
	rewind(fp);
	printf("Enter Your Password:");
	scanf("%s",&strongPassword);
	if(strcmp(strongPassword,v1[SN].password))
	{
	printf("Wrong password.");
		return 0;
	}

	printf("\nCandidateID  \tCANDIDATE_Name\t\tCANDIDATE_Party\t\n");                         
	for(i=0;i<count;i++){
		fscanf(fp,"%d",&c1[i].id);
		printf("%-20d",c1[i].id);
		fscanf(fp,"%s",&c1[i].name);
		printf("%-20s",c1[i].name);
		fscanf(fp,"%s",&c1[i].party);
		printf("%-20s\n",c1[i].party);
		fscanf(fp,"%s",&c1[i].location);
		
		
	}
	
	fclose(fp);
	printf("Input the ID of the Candidate You Wish to Vote for:");             
	scanf("%d",&number);
	fp=fopen("votecount.txt","r+");
	if(fscanf(fp,"%s",&no_candidate)==EOF)
	{           	                                             
		for(i=0;i<count;i++)
		{                       
			if (number==i+1)
			{
				c1[i].votecount+=1;
			}
			fprintf(fp,"%d\t%s",c1[i].votecount,c1[i].name);              
			if(i<count-1)
			{                                               
				fprintf(fp,"\n");
			}
		}
		
	}
	else
	{                                          
		rewind(fp);
		for(i=0;i<count;i++){
				fscanf(fp,"%d%s",&c1[i].votecount,&c1[i].name);
			
				if(number==i+1){                                     
					c1[i].votecount+=1;                       
				}                                                          
				
			}		
	}
	
	fclose(fp);
	fopen("votecount.txt","w");                      
	for(i=0;i<count;i++){
		
			fprintf(fp,"%d\t%s",c1[i].votecount,c1[i].name);
			if(i<count-1){                                         
				fprintf(fp,"\n");
			}
		}
	fclose(fp);
	printf("Voted Successfully");
	return 0;
}



