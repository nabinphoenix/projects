int SEE_CANDIDATE(){
	FILE *fp;
	int i;
	char emptycheck[20];
	fp=fopen("candidatelist.txt","r");
	int count=file_line_count(fp);
	rewind(fp);
	if(fscanf(fp,"%s",&emptycheck)==EOF){
		printf("Candidate list does not exists.");
		return 0;
	}
	c c1[count];
	rewind(fp);
	
	printf("\ncandidate id\tcandidate_name\t\tparty\t\tlocation\n");
	for(i=0;i<count;i++){
		fscanf(fp,"%d",&c1[i].id);
		printf("%-20d",c1[i].id);
		fscanf(fp,"%s",&c1[i].name);
		printf("%-20s",c1[i].name);
		fscanf(fp,"%s",&c1[i].party);
		printf("%-20s",c1[i].party);
		fscanf(fp,"%s",&c1[i].location);
		printf("%-20s\n",c1[i].location);
	}
	return 0;
}

int REMOVE_CANDIDATE(){
	char ch,str[20];
	int count,del,i,remove_check=0, j=1;
	FILE * fp;
	fp=fopen("candidate.txt","r");
	if(fp==NULL){
		printf("unable to open the file.");
		return 0;
	}
	if(fscanf(fp,"%s",&str)==EOF){
		printf("\nFile is empty.\n");
		return 0;
	}
	count=file_line_count(fp);
	rewind(fp);
	c s1[count];

	for(i=0;i<count;i++){
		fscanf(fp,"%d",&s1[i].id);
		
		fscanf(fp,"%s",&s1[i].name);
		
		fscanf(fp,"%s",&s1[i].party);
		fscanf(fp,"%s",&s1[i].location);
	}
	
	
	fclose(fp);
	printf("\nInput ID of the Candidate that you wish to Remove the details of:");
	scanf("%d",&del);
	fp=fopen("candidatelist.txt","w+");
	for(i=0;i<count;i++){
		if(s1[i].id==del){
			remove_check+=1;
			continue;
		}
		if(j!=1){
			fprintf(fp,"\n");
		}
		fprintf(fp,"%d\t",j);
		fprintf(fp,"%s\t",s1[i].name);
		fprintf(fp,"%s\t",s1[i].party);
		fprintf(fp,"%s",s1[i].location);
		j+=1;
		
		
	}
	if(remove_check==1){
	
	printf("Candidate no %d is removed from the list.\n",del);
	}
	else {
		printf("Candidate with that ID does not exists.");
	}
	fclose(fp);
	return 0;
}
int CANDIDATE_ADDITION(){
	FILE * fp ;
	int count;
	fp=fopen ("candidatelist.txt","r");
	char str[20];
	if(fscanf(fp,"%s",&str)==EOF){
		printf("You should create a candidatelist List first.\n");
		return 0;
	}
	rewind(fp);
	char name[300];
	char party[300];
	char address[300];
	count=file_line_count(fp);
	
	fclose(fp);
	fopen("candidatelist.txt","a");
	fprintf(fp,"\n%d\t",count+1);
	printf("Input the name of the Candidate you want to add:");
	scanf("%s",&name);
	fprintf(fp,"%s\t",name);
	printf("Input the Political Party of the Candidate:");
	scanf("%s",&party);
	fprintf(fp,"%s\t",party);
	printf("Input the address of Candidacy:");
	scanf("%s",&address);
	fprintf(fp,"%s",address);
	printf("\nDONE\n");
	fclose(fp);
	return 0;
}
int MODIFY_CANDIDATE(){
	int n;
	printf("\n\nchoose the options below:\n-press 1 if you want do delete a candidate from the list\n-press 2 to add a candidate to the list\n-press other numbers to exit\n");
	scanf("%d",&n);
	switch(n)
	{
		case 1:
			REMOVE_CANDIDATE();
			break;
		case 2:
			CANDIDATE_ADDITION();
			break;
		default:
			return 0;
	}
	return 0;
}
int  VIEW_VOTES(){
	FILE * fp ;
	
	
	fp=fopen ("votecount.txt","r");
	if(fp==NULL){
		printf("Unable to open votecount file.");
		return 0;
	}
	int count=file_line_count(fp),i;
	c c1[count];
	rewind(fp);
	for (i=0;i<count;i++){
		fscanf(fp,"%d",&c1[i].votecount);
		fscanf(fp,"%s",&c1[i].name);
		
	}
	printf("The vote count is:\n");
	for(i=0;i<count;i++){
		printf("%s recieved %d votes\n",c1[i].name,c1[i].votecount);
	}
	fclose (fp); 
	return 0;	
}
int SCHEDULE_CREATION(){
	int n,i; 
	FILE *fp;

	
	fp = fopen ("schedule.txt","w");
	if(fp==NULL){
		printf("Unable to open the file.");
		return 0;
	}

	printf("Enter the number of constituencies:");
	scanf("%d",&n);
	s constituency[n];
	for ( i=0;i<n;i++){
		printf("Enter the name of constituency %d:",i+1);
		scanf("%s",&constituency[i].name);
		fprintf(fp,"%s\t",constituency[i].name);
		printf("Enter the date of election in %s:",constituency[i].name);
		scanf("%s",&constituency[i].date);
		fprintf(fp,"%s\n",constituency[i].date);
	}
	fclose(fp);
	printf("Election schedule created and saved successfully.");
	return 0;
}
int REGISTER_CANDIDATE(){
	int n,i;
	FILE *cd;

	cd=fopen("candidatelist.txt","w");
	if(cd==NULL){
		printf("unable to open file.");
	}
	printf("Enter the number of candidates:");
	scanf("%d",&n);
	c candidate[n];
	for (i=0;i<n;i++){
		fprintf(cd,"%d\t",i+1);
		printf("Enter the name of candidate %d:",i+1);
		scanf("%s",&candidate[i].name);
		fprintf(cd,"%s\t",candidate[i].name);
		printf("Enter the party of candidate %d:",i+1);
		scanf("%s",&candidate[i].party);
		fprintf(cd,"%s\t",candidate[i].party);
		printf("Enter the location of candidacy of candidate %d:",i+1);
		scanf("%s",&candidate[i].location);
		fprintf(cd,"%s",candidate[i].location);
		if(i<n-1){
			fprintf(cd,"\n");
		}
	}
	fclose(cd);
	printf("Candidate details added and saved successfully.\n");
	return 0;
}
int SEE_SCHEDULE(){
	FILE *fp;
	fp=fopen("schedule.txt","r");
	if(fp==NULL){
		printf("unable to open the file\n");
		return 0;
	}
	
	char name[50],date[50];
	if(fscanf(fp,"%s",&name)==EOF){
		printf("\nSchedule not created");
		return 0;
	}
	rewind(fp);
	printf("\nThe schedule is:\n");
	printf("constituency\tdate\n");
	while(fscanf(fp,"%s%s",&name,&date)!=EOF){
		printf("%-16s%s\n",name,date);
	}
	fclose(fp);
	return 0;
}
