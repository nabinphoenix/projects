#include<stdio.h>   
#include<string.h>
#include"header.h" //// This is  the header file which contains function prototypes
#include"administrator.c"  ////// It includes the Admin related functions
#include"voter.c"		// Similarly , it includes the voter related functions
int voter();		// Function
int admin();		//	Prototypes
int main(){
	int number;
	do{
	
	number=CHECK_VOTER_OR_ADMIN();
	switch(number){
	case 2:
		voter();
		break;
	
	case 1:
		admin();
		break;
	
	default:
		printf("INVALID OPTIONS");
		return 0;
	}
	

	}while (number!=0);
	return 0;
}
//Admin related functions	
int admin(){
	if(check_admin())
	{
		int CHOSE_OPTION;
		while(CHOSE_OPTION==1||CHOSE_OPTION==2||CHOSE_OPTION==3||CHOSE_OPTION==4||CHOSE_OPTION==5||CHOSE_OPTION==6){
		printf("\n\n**************************\"ADMIN DISPLAY\"***************************\nChoose the options below:\n");
		printf("1.To Create New Election Schedule\n");
		printf("2.To View Election Schedule\n");
		printf("3.To Create New Candidate List\n");
		printf("4.To Modify Existing Candidate List\n");
		printf("5.To View Candidate List\n");
		printf("6.To See Election Result\n");
		
		printf("-Enter Any Other Numbers to Exit to the Main menu\n");
		scanf("%d",&CHOSE_OPTION);

		
		switch(CHOSE_OPTION){
			case 1:
				SCHEDULE_CREATION();
				break;
			case 2:
				SEE_SCHEDULE();
				break;
			case 3:
				REGISTER_CANDIDATE();
				break;
			case 4:
				MODIFY_CANDIDATE();
				break;
			case 5:
				SEE_CANDIDATE();
				break;
			case 6:
				VIEW_VOTES();
				break;
			default:
				return 0;
		}
	}
			
	}
	return 0;	
}
//Voter related function
int voter(){
	int choice;
	while(choice==1||choice==2||choice==3||choice==4||choice==5)
	{
	
		printf("\n\n***********************\"VOTER'S DISPLAY\"*****************************\nCHOOSE THE OPTIONS BELOW:\n");
		printf("1.To Register Your Details:\n");
		printf("2.To View Your Details:\n");
		printf("3.To Modify  Your Details:\n");
		printf("4.To Caste Your Vote:\n");
		scanf("%d",&choice);
		switch(choice){
		case 1:
			VOTER_REGISTRATION();
			break;
		case 2:
			SEE_VOTER_INFORMATION();
			break;
		case 3:
			MODIFY_VOTER_INFO();
			break;
		case 4:
			VOTE_CASTING();
			return 0;
			break;
		default:
			printf("\nThank You For Using the Election Management System.\n");
		}
	}
	return 0;
}
