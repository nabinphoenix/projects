typedef struct schedule   // Defining  a structure called schedule
{    
	char name[600];       // A character array to store the name
	char date[500];
}s;                       //s represents  structure name schedule.
typedef struct candidate{
	int id;
	char name[600];
	char party[300];
	char location[800];
	int  votecount = 0;
}c;    						//c represents  structure name candidate
typedef struct voter{
	int sno;
	char firstname[500];
	char lastname[500];
	char dob[500];
	char address[500];
	char password[500];
	int votecheck=1;
	
}v;							//v represents  structure name voter
int check_admin(){
	char strongPassword[600];
	printf("Enter Password:");
	scanf("%s",&strongPassword);
	if(strcmp(strongPassword,"admin@@@")){   // Compare the entered password with the correct admin password
		printf("Soory,Password is incorrect enter again:");
		scanf("%s",&strongPassword);
		if(strcmp(strongPassword,"admin@@@")){
			printf("Access denied");      //if the password is still incorrect, deny access
			return 0;
		}
		return 1; // If the password is correct, then Admin can access Admin Display
	}
	return 1;   // Firstly or at the starting , If the password is correct . Admin Can direclty access Adimn Dispaly
}
int CHECK_VOTER_OR_ADMIN(){
	int check;
	printf("\n\n*****************************************\"ELECTION MANAGEMENT SYSTEM\"**************************************************");
	printf("\nAre you an Admin or Voter?\n->Enter 1 if you are Admin\n->Enter 2 if you are a Voter\n->Enter any other number if you want to exit the system.\n");
	scanf("%d",&check);                          
	switch(check){
		case 1:
			return 1;	//It returns 1 if the user is ADMIN
			break;
		case 2:
			return 2;    //It returns 2 if the user is VOTER
			break;
		case 0:
			return 0;	//It returns 0 if the user don't want to use Election Management System
	}
	
}
int file_line_count(FILE *fp){ 			// This is a function which count the number of lines in a file
	char ch;
	int count=1;
	while (fscanf(fp,"%c",&ch)!=EOF){	// Read characters from the file until the end of file(EOF)
		if(ch=='\n'){
			count ++;		// Increment the count when a newline character is encountered
		}
	}
	return count;		// It returns the total number of line count
}





