# background_tasks/__init__.py
from .email_tasks import send_welcome_email, send_account_deletion_email

__all__ = ["send_welcome_email", "send_account_deletion_email"]
