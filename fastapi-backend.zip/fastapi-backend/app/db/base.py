# app/db/base.py
from sqlmodel import SQLModel
from app.db.models import User, Todo

metadata = SQLModel.metadata
