from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
from app.db.models import Todo
from typing import Optional, List

# Create a new todo
async def create_todo(session: AsyncSession, title: str, description: Optional[str], user_id: int) -> Todo:
    todo = Todo(title=title, description=description, user_id=user_id)
    session.add(todo)
    await session.commit()
    await session.refresh(todo)
    return todo

# Get todo by id
async def get_todo(session: AsyncSession, todo_id: int) -> Optional[Todo]:
    result = await session.execute(select(Todo).where(Todo.id == todo_id))
    return result.scalars().first()

# List todos for a specific user
async def list_user_todos(session: AsyncSession, user_id: int) -> List[Todo]:
    result = await session.execute(select(Todo).where(Todo.user_id == user_id))
    return result.scalars().all()

# List all todos (for superuser)
async def list_all_todos(session: AsyncSession) -> List[Todo]:
    result = await session.execute(select(Todo))
    return result.scalars().all()

# Update todo
async def update_todo(session: AsyncSession, todo: Todo, title: str, description: Optional[str], completed: bool) -> Todo:
    todo.title = title
    todo.description = description
    todo.completed = completed
    session.add(todo)
    await session.commit()
    await session.refresh(todo)
    return todo

# Delete todo
async def delete_todo(session: AsyncSession, todo: Todo):
    await session.delete(todo)
    await session.commit()
