from sqlmodel.ext.asyncio.session import AsyncSession
from sqlmodel import select
from app.db.models import User
from app.auth.security import hash_password
from typing import Optional

# Create a new user
async def create_user(session: AsyncSession, username: str, email: str, password: str, is_superuser: bool = False) -> User:
    hashed = hash_password(password)
    user = User(username=username, email=email, hashed_password=hashed, is_superuser=is_superuser)
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user

# Get user by username
async def get_user_by_username(session: AsyncSession, username: str) -> Optional[User]:
    result = await session.execute(select(User).where(User.username == username))
    return result.scalars().first()

# Get user by id
async def get_user_by_id(session: AsyncSession, user_id: int) -> Optional[User]:
    result = await session.execute(select(User).where(User.id == user_id))
    return result.scalars().first()

# List all users (superuser)
async def list_users(session: AsyncSession):
    result = await session.execute(select(User))
    return result.scalars().all()

# Update user
async def update_user(session: AsyncSession, user: User, username: Optional[str] = None, email: Optional[str] = None, password: Optional[str] = None):
    if username is not None:
        user.username = username
    if email is not None:
        user.email = email
    if password is not None:
        user.hashed_password = hash_password(password)
    session.add(user)
    await session.commit()
    await session.refresh(user)
    return user

# Delete user
async def delete_user(session: AsyncSession, user: User):
    # First delete all todos associated with the user
    from app.db.models import Todo
    todos_to_delete = await session.execute(select(Todo).where(Todo.user_id == user.id))
    todos = todos_to_delete.scalars().all()
    
    for todo in todos:
        await session.delete(todo)
    
    # Then delete the user
    await session.delete(user)
    await session.commit()
