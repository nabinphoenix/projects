from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

# Used for user registration
class UserCreate(BaseModel):
    username: str
    email: EmailStr
    password: str

# Used for user updates (partial updates)
class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = None

# Used for user updates with password verification
class UserUpdateWithPassword(BaseModel):
    current_password: str
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    new_password: Optional[str] = None

# Used for user deletion with password verification
class UserDeleteWithPassword(BaseModel):
    current_password: str

# Used for reading user info (response)
class UserRead(BaseModel):
    id: int # Changed from UUID to int
    username: str
    email: EmailStr
    created_at: datetime
    is_superuser: bool

    class Config:
        orm_mode = True

# Used for login request
class UserLogin(BaseModel):
    username: str
    password: str

# JWT Token response
class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

# Delete response
class DeleteResponse(BaseModel):
    message: str

  

