from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


# Used for creating a new todo
class TodoCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=2000)
    completed: Optional[bool] = False


# Used for reading a todo (response)
class TodoRead(BaseModel):
    id: int
    title: str
    description: Optional[str]
    completed: bool
    created_at: datetime
    user_id: int  # reference to User.id

    class Config:
        orm_mode = True
