from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlmodel.ext.asyncio.session import AsyncSession
from app.db.database import get_session
from app.db.crud.user import get_user_by_username
from app.auth.security import verify_token
from app.db.models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Simple function to get user from token (no superuser check)
async def get_current_normal_user(
    token: str = Depends(oauth2_scheme), 
    session: AsyncSession = Depends(get_session)
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        username = verify_token(token, credentials_exception)
        user = await get_user_by_username(session, username)
        if user is None:
            raise credentials_exception
        return user
    except HTTPException:
        # Re-raise HTTP exceptions (like privilege errors) as-is
        raise
    except Exception as e:
        # Only catch unexpected exceptions and convert to credentials exception
        raise credentials_exception

# For admin users (with superuser check)
async def get_current_active_superuser(
    token: str = Depends(oauth2_scheme), 
    session: AsyncSession = Depends(get_session)
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        username = verify_token(token, credentials_exception)
        user = await get_user_by_username(session, username)
        if user is None:
            raise credentials_exception
        
        if not user.is_superuser:
            raise HTTPException(status_code=400, detail="The user doesn't have enough privileges")
        
        return user
    except Exception as e:
        if "doesn't have enough privileges" in str(e):
            raise e
        raise credentials_exception
