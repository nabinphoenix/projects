# app/core/init_superuser.py
from app.db.crud.user import get_user_by_username, create_user
from app.db.database import get_session
from app.core.config import settings

async def create_first_superuser():
    async for session in get_session():
        try:
            existing = await get_user_by_username(session, settings.FIRST_SUPERUSER_USERNAME)
            if existing:
                print("Superuser already exists")
                return
            await create_user(
                session,
                username=settings.FIRST_SUPERUSER_USERNAME,
                email=settings.FIRST_SUPERUSER_EMAIL,
                password=settings.FIRST_SUPERUSER_PASSWORD,
                is_superuser=True
            )
            print("Superuser created successfully")
        except Exception as e:
            print(f"Error creating superuser: {e}")
        break
